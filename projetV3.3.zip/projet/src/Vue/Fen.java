/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vue;

import Modele.Connexion;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.*;


/**
 *
 * @author Merlo
 */
public class Fen extends JFrame implements ActionListener {
    
    //déclaration des éléments swing et d'un objet Connexion 
    private JTabbedPane connRech;
    private JTabbedPane classe;
    private Connexion maco;
    private JLabel logECE, passwdECE, logBDD, passwdBDD, nameBDD;
    private JTextField logECEText, logBDDText, nameBDDText;
    private JPasswordField passwdECEText, passwdBDDText;
    private JButton connECE, connBDD, execReq, fenMaj,fenMaj2,reqEnr;
    private java.awt.List listeDeTables, listeDeRequetes;
    private JPanel pan1,pan2,pan3,pan4,pan5,pan6,pan7,pan8,panA,panB,panA1,panA2,panB1,res;
    private JScrollPane scroll;
	
    //déclaration des ArrayList pour récupérer les valeurs entrées dans le module recherche 
    ArrayList<JTextField> textes_malade = new ArrayList<JTextField>();
    ArrayList<JTextField> textes_service = new ArrayList<JTextField>();
    ArrayList<JTextField> textes_chambre = new ArrayList<JTextField>();
    ArrayList<JTextField> textes_soin = new ArrayList<JTextField>();
    ArrayList<JTextField> textes_employe = new ArrayList<JTextField>();
    ArrayList<JTextField> textes_hospitalisation = new ArrayList<JTextField>();
    ArrayList<JTextField> textes_docteur = new ArrayList<JTextField>();
    ArrayList<JTextField> textes_infirmier = new ArrayList<JTextField>();
    
    public Fen(){
        //appel du constructeur de JFrame et definition de la fenêtre 
        super("Connexion et recharche dans la BDD");
        this.setLayout(new BorderLayout());
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(800, 800);
        
        // creation des listes pour les tables et les requetes
        listeDeTables = new java.awt.List(10, false);
        listeDeRequetes = new java.awt.List(10, false);
        
        //instance des JTabbedPane
        connRech = new JTabbedPane();
        classe =  new JTabbedPane();
        //ajout du JTabbedPane principal à la fenêtre 
        this.add(connRech);
       
        
        panA= new JPanel();
        panA1= new JPanel();
        panA2= new JPanel();
        res= new JPanel();
        panB= new JPanel();
        pan1= new JPanel();
        pan2= new JPanel();
        pan3= new JPanel();
        pan4= new JPanel();
        pan5= new JPanel();
        pan6= new JPanel();
        pan7= new JPanel();
        pan8= new JPanel();
        
        //ajout des pan princpaux au TabbedPane de Connexin et Recheche
        connRech.add("Connexion", panA);
        connRech.add("Rechercher",panB);
        
        // on definit le Layout des pan principaux 
        panA.setLayout(new BorderLayout());
        panB.setLayout(new BorderLayout());
        
        //ajout des pans au TabbedPane
        classe.add("Malade", pan1);
        classe.add("Service", pan2);
        classe.add("Chambre", pan3);
        classe.add("Soin", pan4);
        classe.add("Employé", pan5);
        classe.add("Hospitalisation", pan6);
        classe.add("Docteur", pan7);
        classe.add("Infirmier", pan8);
        
        panB.add(classe,BorderLayout.NORTH);
        
        //instance des JLabel
        logECE= new JLabel("Login ECE",JLabel.CENTER); //creation des textes 
        passwdECE= new JLabel("Password ECE",JLabel.CENTER); 
        logBDD= new JLabel("Login BDD",JLabel.CENTER); 
        passwdBDD= new JLabel("Password BDD",JLabel.CENTER); 
        nameBDD= new JLabel("Nom BDD",JLabel.CENTER); 
        
        //instance des boutons
        connECE = new JButton("Connexion ECE");
        connBDD = new JButton("Connexion BDD");
        execReq= new JButton("Rechercher");
        fenMaj = new JButton("Effectuer une Maj \n(ouvre une autre fenetre)");
        fenMaj2 = new JButton("Effectuer une Maj \n(ouvre une autre fenetre)");
        reqEnr = new JButton("Effectuer les requêtes enregistrées");
        
        execReq.setBackground(Color.RED);
        fenMaj.setBackground(Color.GREEN);
        fenMaj2.setBackground(Color.GREEN);
        execReq.setForeground(Color.BLUE);
        fenMaj.setForeground(Color.BLUE);
        fenMaj2.setForeground(Color.BLUE);
        reqEnr.setForeground(Color.BLUE);
        
        logECEText = new JTextField(); //emplacement pour ecrire 
        logBDDText = new JTextField();
        nameBDDText = new JTextField();
        
        passwdECEText = new JPasswordField(8); //emplacement pour ecrire mdp
        passwdBDDText = new JPasswordField(8);
        
        //redimensionnement des JTextField
        connECE.setPreferredSize(new Dimension(150,30));
        connBDD.setPreferredSize(new Dimension(150,30));
        logECEText.setPreferredSize(new Dimension(100,20));
        logBDDText.setPreferredSize(new Dimension(100,20));
        nameBDDText.setPreferredSize(new Dimension(100,20));
        passwdECEText.setPreferredSize(new Dimension(100,20));
        passwdBDDText.setPreferredSize(new Dimension(100,20));
        
        //Action listener pour les boutons
        connECE.addActionListener(this);
        connBDD.addActionListener(this);
        execReq.addActionListener(this);
        fenMaj.addActionListener(this);
        fenMaj2.addActionListener(this);
        reqEnr.addActionListener(this);
        
        //  ajout des élément aux differents pans
        panA1.add(logECE);  //pan Connexion
        panA1.add(logECEText);
        panA1.add(passwdECE);
        panA1.add(passwdECEText);
        panA2.add(logBDD);
        panA2.add(logBDDText);
        panA2.add(passwdBDD);
        panA2.add(passwdBDDText);
        panA2.add(nameBDD);
        panA2.add(nameBDDText);
        panA1.add(connECE);
        panA2.add(connBDD);
        
        panA.add(panA1,BorderLayout.NORTH);
        panA.add(panA2,BorderLayout.CENTER);
        panA.add(fenMaj2,BorderLayout.SOUTH);
        
        //pan Recherche 
        panB1 = new JPanel(new GridLayout(1,3));
        panB1.add(execReq);
        panB1.add(fenMaj);
        panB1.add(reqEnr);
        panB.add(panB1,BorderLayout.SOUTH);
        
        //pan pour affichage des resultats 
        res.setBackground(Color.WHITE);
        scroll = new JScrollPane(res,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        
        scroll.setLayout(new ScrollPaneLayout());
        scroll.setSize(new Dimension(300, 300));
        panB.add(scroll,BorderLayout.CENTER);
        
       
       
        
        mal();
        serv();
        ch();
        soigne();
        empl();
        hospi();
        doc();
        inf();
        
        this.setVisible(true);
        
    }
    //creation des des pan pour TabbedPane pour chaque table
    public void mal(){
        pan1.setLayout(new GridLayout(3,2));
        JLabel label1 = new JLabel("Numero");
        JLabel label2 = new JLabel("Nom");
        JLabel label3 = new JLabel("Prenom");
	JLabel label4 = new JLabel("Adresse");
	JLabel label5 = new JLabel("Telephone");
        JLabel label6 = new JLabel("Mutuelle");
        
        JTextField text1 = new JTextField();
	JTextField text2 = new JTextField();
	JTextField text3 = new JTextField();
	JTextField text4 = new JTextField();
	JTextField text5 = new JTextField();
        JTextField text6 = new JTextField();
        
        text1.setPreferredSize(new Dimension(100,20));
        text2.setPreferredSize(new Dimension(100,20));
        text3.setPreferredSize(new Dimension(100,20));
        text4.setPreferredSize(new Dimension(100,20));
        text5.setPreferredSize(new Dimension(100,20));
        text6.setPreferredSize(new Dimension(100,20));
        
        JPanel p1 = new JPanel();
	JPanel p2 = new JPanel();
	JPanel p3 = new JPanel();
	JPanel p4 = new JPanel();
	JPanel p5 = new JPanel();
	JPanel p6 = new JPanel();
        
        textes_malade.add(text1);
        textes_malade.add(text2);
        textes_malade.add(text3);
        textes_malade.add(text4);
        textes_malade.add(text5);
        textes_malade.add(text6);
        
        p1.add(label1);
        p1.add(text1);
        p2.add(label2);
        p2.add(text2);
        p3.add(label3);
        p3.add(text3);
        p4.add(label4);
        p4.add(text4);
        p5.add(label5);
        p5.add(text5);
        p6.add(label6);
        p6.add(text6);
      
        
        pan1.add(p1);
        pan1.add(p2);
        pan1.add(p3);
        pan1.add(p4);
        pan1.add(p5);
        pan1.add(p6);
           
    }
    public void serv(){
        pan2.setLayout(new GridLayout(2,4));
        JLabel label1 = new JLabel("Code");
        JLabel label2 = new JLabel("Nom");
        JLabel label3 = new JLabel("Batiment");
	JLabel label4 = new JLabel("Directeur");

        
        JTextField text1 = new JTextField();
	JTextField text2 = new JTextField();
	JTextField text3 = new JTextField();
	JTextField text4 = new JTextField();
	
        text1.setPreferredSize(new Dimension(100,20));
        text2.setPreferredSize(new Dimension(100,20));
        text3.setPreferredSize(new Dimension(100,20));
        text4.setPreferredSize(new Dimension(100,20));
        
        JPanel p1 = new JPanel();
	JPanel p2 = new JPanel();
	JPanel p3 = new JPanel();
	JPanel p4 = new JPanel();
	
        
        textes_service.add(text1);
        textes_service.add(text2);
        textes_service.add(text3);
        textes_service.add(text4);
    
        
        p1.add(label1);
        p1.add(text1);
        p2.add(label2);
        p2.add(text2);
        p3.add(label3);
        p3.add(text3);
        p4.add(label4);
        p4.add(text4);
   
        pan2.add(p1);
        pan2.add(p2);
        pan2.add(p3);
        pan2.add(p4);
   
     } 
    public void ch(){
        pan3.setLayout(new GridLayout(2,4));
        JLabel label1 = new JLabel("Code Service");
        JLabel label2 = new JLabel("Numero chambre");
        JLabel label3 = new JLabel("Surveillant");
	JLabel label4 = new JLabel("Nombre lit");

        
        JTextField text1 = new JTextField();
	JTextField text2 = new JTextField();
	JTextField text3 = new JTextField();
	JTextField text4 = new JTextField();

        text1.setPreferredSize(new Dimension(100,20));
        text2.setPreferredSize(new Dimension(100,20));
        text3.setPreferredSize(new Dimension(100,20));
        text4.setPreferredSize(new Dimension(100,20));
        
        JPanel p1 = new JPanel();
	JPanel p2 = new JPanel();
	JPanel p3 = new JPanel();
	JPanel p4 = new JPanel();

        
        textes_chambre.add(text1);
        textes_chambre.add(text2);
        textes_chambre.add(text3);
        textes_chambre.add(text4);
      
        
        p1.add(label1);
        p1.add(text1);
        p2.add(label2);
        p2.add(text2);
        p3.add(label3);
        p3.add(text3);
        p4.add(label4);
        p4.add(text4);
    
        pan3.add(p1);
        pan3.add(p2);
        pan3.add(p3);
        pan3.add(p4);
   
    } 
    public void soigne(){
        pan4.setLayout(new GridLayout(1,2));
        JLabel label1 = new JLabel("Numero Docteur");
	JLabel label2 = new JLabel("Numero Malade");
        
        JTextField text1 = new JTextField();
	JTextField text2 = new JTextField();
        
        text1.setPreferredSize(new Dimension(100,20));
        text2.setPreferredSize(new Dimension(100,20));
        
        JPanel p1 = new JPanel();
	JPanel p2 = new JPanel();
        
        textes_soin.add(text1);
        textes_soin.add(text2);
        
        p1.add(label1);
        p1.add(text1);
        p2.add(label2);
        p2.add(text2);
        
        pan4.add(p1);
        pan4.add(p2);
    }
    public void empl(){
        pan5.setLayout(new GridLayout(3,4));
        JLabel label1 = new JLabel("Numero");
        JLabel label2 = new JLabel("Nom");
        JLabel label3 = new JLabel("Prenom");
	JLabel label4 = new JLabel("Adresse");
	JLabel label5 = new JLabel("Telephone");
        
        JTextField text1 = new JTextField();
	JTextField text2 = new JTextField();
	JTextField text3 = new JTextField();
	JTextField text4 = new JTextField();
	JTextField text5 = new JTextField();
        
        text1.setPreferredSize(new Dimension(100,20));
        text2.setPreferredSize(new Dimension(100,20));
        text3.setPreferredSize(new Dimension(100,20));
        text4.setPreferredSize(new Dimension(100,20));
        text5.setPreferredSize(new Dimension(100,20));
        
        JPanel p1 = new JPanel();
	JPanel p2 = new JPanel();
	JPanel p3 = new JPanel();
	JPanel p4 = new JPanel();
	JPanel p5 = new JPanel();
	
        
        textes_employe.add(text1);
        textes_employe.add(text2);
        textes_employe.add(text3);
        textes_employe.add(text4);
        textes_employe.add(text5);
        
        p1.add(label1);
        p1.add(text1);
        p2.add(label2);
        p2.add(text2);
        p3.add(label3);
        p3.add(text3);
        p4.add(label4);
        p4.add(text4);
        p5.add(label5);
        p5.add(text5);
      
        
        pan5.add(p1);
        pan5.add(p2);
        pan5.add(p3);
        pan5.add(p4);
        pan5.add(p5);
           
    }
    public void hospi(){
        pan6.setLayout(new GridLayout(2,4));
        JLabel label1 = new JLabel("Numero malade");
        JLabel label2 = new JLabel("Code service");
        JLabel label3 = new JLabel("Numero chambre");
	JLabel label4 = new JLabel("Lit");
	
        
        JTextField text1 = new JTextField();
	JTextField text2 = new JTextField();
	JTextField text3 = new JTextField();
	JTextField text4 = new JTextField();
        
        
        text1.setPreferredSize(new Dimension(100,20));
        text2.setPreferredSize(new Dimension(100,20));
        text3.setPreferredSize(new Dimension(100,20));
        text4.setPreferredSize(new Dimension(100,20));
        
        
        JPanel p1 = new JPanel();
	JPanel p2 = new JPanel();
	JPanel p3 = new JPanel();
	JPanel p4 = new JPanel();
        
        textes_hospitalisation.add(text1);
        textes_hospitalisation.add(text2);
        textes_hospitalisation.add(text3);
        textes_hospitalisation.add(text4);
        
        p1.add(label1);
        p1.add(text1);
        p2.add(label2);
        p2.add(text2);
        p3.add(label3);
        p3.add(text3);
        p4.add(label4);
        p4.add(text4);
        
        pan6.add(p1);
        pan6.add(p2);
        pan6.add(p3);
        pan6.add(p4);
    } 
    public void doc(){
        pan7.setLayout(new GridLayout(1,2));
        JLabel label1 = new JLabel("Numero ");
	JLabel label2 = new JLabel("Specialité");
        
        JTextField text1 = new JTextField();
	JTextField text2 = new JTextField();
        
        text1.setPreferredSize(new Dimension(100,20));
        text2.setPreferredSize(new Dimension(100,20));
        
        JPanel p1 = new JPanel();
	JPanel p2 = new JPanel();
        
        textes_docteur.add(text1);
        textes_docteur.add(text2);
        
        p1.add(label1);
        p1.add(text1);
        p2.add(label2);
        p2.add(text2);
        
        pan7.add(p1);
        pan7.add(p2);
    }
    public void inf(){
        pan8.setLayout(new GridLayout(3,4));
        JLabel label1 = new JLabel("Numero");
        JLabel label2 = new JLabel("Nom");
        JLabel label3 = new JLabel("Prenom");
	JLabel label4 = new JLabel("Adresse");
        
        JTextField text1 = new JTextField();
	JTextField text2 = new JTextField();
	JTextField text3 = new JTextField();
	JTextField text4 = new JTextField();
        
        text1.setPreferredSize(new Dimension(100,20));
        text2.setPreferredSize(new Dimension(100,20));
        text3.setPreferredSize(new Dimension(100,20));
        text4.setPreferredSize(new Dimension(100,20));
        
        JPanel p1 = new JPanel();
	JPanel p2 = new JPanel();
	JPanel p3 = new JPanel();
	JPanel p4 = new JPanel();
	
        
        textes_infirmier.add(text1);
        textes_infirmier.add(text2);
        textes_infirmier.add(text3);
        textes_infirmier.add(text4);
        
        p1.add(label1);
        p1.add(text1);
        p2.add(label2);
        p2.add(text2);
        p3.add(label3);
        p3.add(text3);
        p4.add(label4);
        p4.add(text4);
      
        
        pan8.add(p1);
        pan8.add(p2); 
        pan8.add(p3);
        pan8.add(p4);
    }
    
    
    /**
     * Méthode privée qui initialise la liste des tables
     */
    private void remplirTables() {
        maco.ajouterTable("chambre");
        maco.ajouterTable("docteur");
        maco.ajouterTable("employe");
        maco.ajouterTable("hospitalisation");
        maco.ajouterTable("infirmier");
        maco.ajouterTable("malade");
        maco.ajouterTable("service");
        maco.ajouterTable("soigne");
    }

    /**
     * Méthode privée qui initialise la liste des requetes de selection
     */
    private void remplirRequetes() {
        maco.ajouterRequete("SELECT prenom, nom FROM ‘malade’ WHERE mutuelle=‘MAAF’;");
        maco.ajouterRequete("SELECT * FROM service");
        maco.ajouterRequete("SELECT * FROM `docteur`;");
        }

    /**
     * Méthode privée qui initialise la liste des requetes de MAJ
     */
    private void remplirRequetesMaj() {
        // Requêtes d'insertion
        maco.ajouterRequeteMaj("INSERT INTO malade (numero, nom, prenom, adresse,tel, mutuelle) VALUES (77,'Henri', 'Dupont,'',Paris');");

        // Requêtes de modification
        maco.ajouterRequeteMaj("UPDATE malade SET loc='Eiffel' WHERE loc='Paris';");

        // Requêtes de suppression
        maco.ajouterRequeteMaj("DELETE FROM malade WHERE ='Eiffel';");

    }
    //  fonction de requete simple de type "SELECT * FROM ..."
    public ArrayList rechMalade(){
           ArrayList arrayL = new ArrayList();
            try {
                arrayL= maco.remplirChampsRequete("SELECT * FROM `malade`");

            } catch (Exception e) {
                System.out.println("Erreur SQL");
            }
            return arrayL;
    }
    public ArrayList rechService(){
           ArrayList arrayL = new ArrayList();
            try {
                arrayL= maco.remplirChampsRequete("SELECT * FROM `service`");

            } catch (Exception e) {
                System.out.println("Erreur SQL");
            }
            return arrayL;
    }
    public ArrayList rechChambre(){
           ArrayList arrayL = new ArrayList();
            try {
                arrayL= maco.remplirChampsRequete("SELECT * FROM `chambre`");

            } catch (Exception e) {
                System.out.println("Erreur SQL");
            }
            return arrayL;
    }
    public ArrayList rechSoigne(){
           ArrayList arrayL = new ArrayList();
            try {
                arrayL= maco.remplirChampsRequete("SELECT * FROM `soigne`");

            } catch (Exception e) {
                System.out.println("Erreur SQL");
            }
            return arrayL;
    }
    public ArrayList rechEmploye(){
           ArrayList arrayL = new ArrayList();
            try {
                arrayL= maco.remplirChampsRequete("SELECT * FROM `employe`");

            } catch (Exception e) {
                System.out.println("Erreur SQL");
            }
            return arrayL;
    }
    public ArrayList rechHospitalisation(){
           ArrayList arrayL = new ArrayList();
            try {
                arrayL= maco.remplirChampsRequete("SELECT * FROM `hospitalisation`");

            } catch (Exception e) {
                System.out.println("Erreur SQL");
            }
            return arrayL;
    }
    public ArrayList rechDocteur(){
           ArrayList arrayL = new ArrayList();
            try {
                arrayL= maco.remplirChampsRequete("SELECT * FROM `docteur`");

            } catch (Exception e) {
                System.out.println("Erreur SQL");
            }
            return arrayL;
    }
    public ArrayList rechInfirmier(){
           ArrayList arrayL = new ArrayList();
            try {
                arrayL= maco.remplirChampsRequete("SELECT * FROM `infirmier`");

            } catch (Exception e) {
                System.out.println("Erreur SQL");
            }
            return arrayL;
    }
    
    
    
    //ajout des resultats au pan de resultats 
    public void result(ArrayList l){
        String str="";
        for(int i=0;i<l.size();i++){
            str = l.get(i).toString();
            res.add(new JLabel(str));
            str= "";
        }
            
    }
    
    
    
    // recupere les champ d'une reqête de type "SELECT .. FROM .. WHERE .."
    public ArrayList reqMalade(String table,String req){
        ArrayList l= new ArrayList();
        try {
             l = maco.remplirChampsRequete("SELECT `nom` , `prenom`  FROM " +table+ " WHERE " + req);

        } catch (Exception e) {
            System.out.println("Erreur SQL");
        }
        return l;
            
    }
    
    public ArrayList reqService(String table, String req){
        ArrayList l= new ArrayList();
        try {
             //l = maco.remplirChampsRequete("SELECT `code` , `nom` , `batiment` , `directeur` FROM "+table+ " WHERE " + req);
             l = maco.remplirChampsRequete("SELECT `code` , `nom` , `batiment` , `directeur` FROM "+table+ " WHERE " + req);


        } catch (Exception e) {
            System.out.println("Erreur SQL1");
        }
        return l;
        
    }
    public ArrayList reqChambre(String table, String req){
        ArrayList l= new ArrayList();
        try {
            l = maco.remplirChampsRequete("SELECT `code_service`,`no_chambre`,`surveillant`,`nb_lits` FROM "+table+ " WHERE " + req);
        }catch (Exception e) {
            System.out.println("Erreur SQL1");
        }
        return l;
        
    }
    public ArrayList reqSoin(String table, String req){
        ArrayList l= new ArrayList();
        try {
            l = maco.remplirChampsRequete("SELECT `no_docteur`,`no_maladee` FROM "+table+ " WHERE " + req);
        }catch (Exception e) {
            System.out.println("Erreur SQL1");
        }
        return l;
        
    }
    public ArrayList reqInfirmier(String table,String requete){
        ArrayList l= new ArrayList();
            try {
                 l = maco.remplirChampsRequete("SELECT 'numero' , 'code_service'  FROM " +table+ "WHERE " + requete);

            } catch (Exception e) {
                System.out.println("Erreur SQL");
            }
            return l;
            
        }
    
    public ArrayList reqDocteur(String table,String requete){
        ArrayList l= new ArrayList();
            try {
                 l = maco.remplirChampsRequete("SELECT 'numero' , 'specialite'  FROM " +table+ "WHERE " + requete);

            } catch (Exception e) {
                System.out.println("Erreur SQL");
            }
            return l;
            
        }
    
    public ArrayList reqHospitalisation(String table,String requete){
        ArrayList l= new ArrayList();
            try {
                 l = maco.remplirChampsRequete("SELECT 'no_malade' , 'code_service'  , 'no_chambre' , 'lit' FROM " +table+ "WHERE " + requete);

            } catch (Exception e) {
                System.out.println("Erreur SQL");
            }
            return l;
            
        }
    
    public ArrayList reqEmploye(String table,String requete){
        ArrayList l= new ArrayList();
            try {
                 l = maco.remplirChampsRequete("SELECT 'numero' , 'nom'  , 'prenom' FROM " +table+ "WHERE " + requete);

            } catch (Exception e) {
                System.out.println("Erreur SQL");
            }
            return l;
            
        }
    
    //Action sur les boutons 
    @Override
    public void actionPerformed(ActionEvent e) {
        Object s = e.getSource(); // on recupere la source de l'action 
        
        //si l'on appuie sur l'un des deux boutons FenMAj, ouverture de la fenetre 
        if(s==fenMaj){
            FenMaj Fmaj = new FenMaj(maco);
        }
        if(s==fenMaj2){
            FenMaj Fmaj = new FenMaj(maco);
        }
        // ouverture de la fenetre d'affichage des requetes 
        if(s==reqEnr){
            ArrayList<String> liste_str =new ArrayList<String>();
            maco.requetes.removeAll(liste_str);
            this.remplirRequetes();
            ReqEnr fenetreReqEnr = new ReqEnr(maco);
        }
        
        // connexion au sefveur ECE 
        if(s==connECE){
            String passwdECEString = new String(passwdECEText.getPassword());
            String passwdBDDString = new String(passwdBDDText.getPassword());
            try {
                try {
                    // tentative de connexion si les 4 attributs sont remplis
                    maco = new Connexion(logECEText.getText(), passwdECEString,logBDDText.getText(), passwdBDDString);

                    // effacer les listes de tables et de requêtes
                    listeDeTables.removeAll();
                    listeDeRequetes.removeAll();

                    // initialisation de la liste des requetes de selection et de MAJ
                    remplirTables();
                    remplirRequetes();
                    remplirRequetesMaj();


                    // se positionner sur la première table et requête de selection
                    listeDeTables.select(0);
                    listeDeRequetes.select(0);

                    // recuperer la liste des lignes de la requete selectionnee
                    String requeteSelectionnee = listeDeRequetes.getSelectedItem();

                    // afficher les résultats de la requete selectionnee
                    //afficherRes(requeteSelectionnee);
                    
                    // reinitialiser les textes 
                    passwdECEText.setText("");
                    logECEText.setText("");
                } catch (ClassNotFoundException cnfe) {
                    System.out.println("Connexion echouee : probleme de classe");
                    cnfe.printStackTrace();
                }
            }catch (SQLException ex) {
                System.out.println("Connexion echouee : probleme SQL");
                ex.printStackTrace();
            }
            finally{
                passwdECEText.setText("");
                logECEText.setText("");
            }
        //connexion locale 
        }else if (s == connBDD) {
            ArrayList<String> liste;
            try{
                try {
                    try {
                        // tentative de connexion si les 4 attributs sont remplis
                        //maco = new Connexion(nameBDDText.getText(), logBDDText.getText(),passwdBDDText.getText());
                        maco = new Connexion("hopital","root","root");
                        // effacer les listes de tables et de requêtes
                        listeDeTables.removeAll();
                        listeDeRequetes.removeAll();

                        // initialisation de la liste des requetes de selection et de MAJ
                        remplirTables();
                        remplirRequetes();
                        remplirRequetesMaj();



                        // se positionner sur la première table et requête de selection
                        listeDeTables.select(0);
                        listeDeRequetes.select(0);

                        // afficher les champs de la table sélectionnée
                        String nomTable = listeDeTables.getSelectedItem();


                        // recuperer la liste des lignes de la requete selectionnee
                        String requeteSelectionnee = listeDeRequetes.getSelectedItem();

                        // afficher les résultats de la requete selectionnee
                        //afficherRes(requeteSelectionnee);

                        // reinitialiser les textes 
                        passwdBDDText.setText("");
                        logBDDText.setText("");
                        nameBDDText.setText("");
                    } catch (ClassNotFoundException cnfe) {
                        System.out.println("Connexion echouee : probleme de classe");
                        cnfe.printStackTrace();
                    }
                } catch (SQLException ex) {
                    System.out.println("Connexion echouee : probleme SQL");
                    ex.printStackTrace();
                }
                finally{
                    passwdBDDText.setText("");
                    logBDDText.setText("");
                    nameBDDText.setText("");
                }
            }catch (ArrayIndexOutOfBoundsException aioobEx){
                
            }
            
        }
        //Execution d'une requete 
        else if(s== execReq){  //si on appuie sur le bouton "Executer
            String req="";
            
            int index = classe.getSelectedIndex();
            //variables utilisées pour recupérer les entiers 
            int a=0; // numero du malade  
            int b=0; // numero directeur service
            int c=0; // numero chambre
            int d= 0; // nombre lits
            int h=0; // numero doc
            int f=0; // num employe
            int g=0; // numero lit
            boolean premierWhere=true; // permet de savoir si besoin d'ajouter un " AND " dans la requête  
            //switch en fonction de l'index du TabbedPAne 
            switch(index){
                case 0 :
                    premierWhere=true;
                    //recuperation des champs des JTextField
                    String s1 = textes_malade.get(1).getText().trim();
                    String s2 = textes_malade.get(2).getText().trim();
                    String s3 = textes_malade.get(3).getText().trim();
                    String s4 = textes_malade.get(4).getText().trim();
                    String s5 = textes_malade.get(5).getText().trim();
                    
                    //si la taille du texte n'est pas nulle alors on récupere l'entier inscrit  
                    if(textes_malade.get(0).getText().length() != 0){
                            a= Integer.parseInt(textes_malade.get(0).getText().trim());
                        }
                    
                    //si aucune valeur n'est rentrée
                    if(s1.compareTo("")==0 && s2.compareTo("")==0 && s3.compareTo("")==0 &&s4.compareTo("")==0 &&s5.compareTo("")==0 && a==0){ // si aucune saisie 
                        res.setLayout(new GridLayout(0,2));
                        res.removeAll();
                        ArrayList liste1 =rechMalade(); //on appelle la fonction de base des requete 
                        res.add(new JLabel("Numero Nom Prenom Adresse Telephone Mutuelle"));   
                        res.add(new JLabel("Numero Nom Prenom Adresse Telephone Mutuelle")); 
                        this.result(liste1);
                    }
                    //sinon on teste chaque valeur  
                    else{
                        if(a!=0){
                            req +="`numero`="+a; //ajout condition 
                            premierWhere = false;  // ce n'est plus le premier WHERE,au prochain if verifié, un AND s'ajotera 
                        }
                        if(s1.compareTo("")!=0){
                            if(premierWhere==false){ /// on verfie s'il s'agit de la première condition 
                                req +=" AND ";
                            }
                            req +="`nom`="+s1; 
                            premierWhere = false;
                        }
                        if(s2.compareTo("")!=0){
                            if(premierWhere==false){
                                req +=" AND ";
                            }
                            req +="`prenom`=‘"+s2+"‘";
                            premierWhere = false;
                        }
                        if(s3.compareTo("")!=0){
                            if(premierWhere==false){
                                req +=" AND ";
                            }
                            req +="‘adresse‘=‘"+s3+"‘";
                            premierWhere = false;
                        }
                        if(s4.compareTo("")!=0){
                            if(premierWhere==false){
                                req +=" AND ";
                            }
                            req +="‘telephone‘=‘"+s4+"‘";
                            premierWhere = false;
                        }
                        if(s5.compareTo("")!=0){
                            if(premierWhere==false){
                                req +=" AND ";
                            }
                            req +="‘mutuelle‘=‘"+s5+"‘";
                            premierWhere = false;
                        }
                        ArrayList liste1 = this.reqMalade("‘malade‘",req); // appel de la fonction reqMalade
                        res.setLayout(new GridLayout(0,2));
                        res.removeAll(); 
                        this.result(liste1);
                        this.repaint();
                    }
                    break;
                case 1 : 
                    req="";
                    premierWhere=true; 
                    String st1 = textes_service.get(0).getText().trim();
                    String st2 = textes_service.get(1).getText().trim();
                    String st3 = textes_service.get(2).getText().trim();
                    
                    if(textes_service.get(3).getText().length() != 0){
                        b= Integer.parseInt(textes_service.get(3).getText().trim());
                    }
                    
                    if(st1.compareTo("")==0 && st2.compareTo("")==0 && st3.compareTo("")==0 && b==0){
                        res.removeAll();
                        res.setLayout(new GridLayout(0,2));
                        ArrayList<String> liste2 =rechService(); //on appelle la fonction de base des requete 
                        this.result(liste2);
                    }
                    else {
                        if(st1.compareTo("")!=0){
                            req += "code="+"`"+st1+"`";
                            premierWhere=false;
                        }
                        if(st2.compareTo("")!=0){
                            if(premierWhere==false){
                                req +=" AND ";
                            }
                            req += "nom="+"`"+st2+"`";
                            premierWhere=false;
                        }
                        if(st3.compareTo("")!=0){
                            if(premierWhere==false){
                                req +=" AND ";
                            }
                            req+= "batiment="+"`"+st3+"`";
                            premierWhere=false;
                        }
                        if(b!=0){
                            if(premierWhere==false){
                                req +=" AND ";
                            }
                            req += "directeur="+"`"+b+"`";
                            premierWhere=false;
                        }
                        if(premierWhere == false){
                            req+=";";
                        }
                        System.out.println(b);
                        ArrayList<String> liste2 = this.reqService("`service`",req);
                        res.removeAll();
                        res.setLayout(new GridLayout(0,2));
                        this.result(liste2);
                        this.repaint();
                    }

                    break;
                case 2 : 
                    c=0;
                    f=0;
                    d=0;
                    req="";
                    premierWhere=true; 
                    String sc1 = textes_chambre.get(0).getText().trim();
                    
                    if(textes_chambre.get(1).getText().length()!=0){
                        c=Integer.parseInt(textes_chambre.get(1).getText().trim());
                    }
                    if(textes_chambre.get(2).getText().length()!=0){
                        f=Integer.parseInt(textes_chambre.get(2).getText().trim());
                    }
                    if(textes_chambre.get(3).getText().length()!=0){
                        d=Integer.parseInt(textes_chambre.get(3).getText().trim());
                    }
                    
                    if(sc1.compareTo("")==0 && c==0 && f==0 && d==0){
                        res.removeAll();
                        res.setLayout(new GridLayout(0,2));
                        ArrayList<String> liste3 =rechChambre(); //on appelle la fonction de base des requete 
                        this.result(liste3);
                    }
                    else {
                        if(sc1.compareTo("")!=0){
                            req += "code_service=`"+sc1+"`";
                            premierWhere=false;
                        }
                        if(c!=0){
                            if(premierWhere==true){
                                req +=" AND ";
                            }
                            req += "no_chambre=`"+c+"`";
                            premierWhere=false;
                        }
                        if(f!=0){
                            if(premierWhere==true){
                                req +=" AND ";
                            }
                            req += "surveillant=`"+c+"`";
                            premierWhere=false;
                        }
                        if(d!=0){
                            if(premierWhere==true){
                                req +=" AND ";
                            }
                            req += "nb_lits=`"+c+"`";
                            premierWhere=false;
                        }
                        System.out.println(b);
                        ArrayList<String> liste3 = this.reqChambre("`chambre`",req);
                        res.removeAll();
                        res.setLayout(new GridLayout(0,2));
                        this.result(liste3);
                        this.repaint();
                    }
                    break;
                case 3 : 
                    req="";
                    premierWhere=true; 
                    a=h=0;
                    if(textes_soin.get(0).getText().length()!=0){
                       h=Integer.parseInt(textes_soin.get(0).getText().trim());
                    }
                    if(textes_soin.get(1).getText().length()!=0){
                       a=Integer.parseInt(textes_soin.get(1).getText().trim());
                    }
                    if(h==0 && a==0){
                        res.setLayout(new GridLayout(0,2));
                        res.removeAll();
                        ArrayList<String> liste4 = this.rechSoigne();
                        this.result(liste4);
                    }
                    else {
                        if(h!=0){
                            req += "no_docteur="+"`"+h+"`";
                            premierWhere=false;
                        }
                        if(a!=0){
                            if(premierWhere==true){
                                req += " AND ";
                            }
                            req += "no_malade="+"`"+a+"`";
                            premierWhere=false;
                        }
                        ArrayList liste = this.reqSoin("`soin`",req);
                        res.removeAll();
                        res.setLayout(new GridLayout(0,2));
                        this.result(liste);
                        this.repaint();
                    }
                    break;
                case 4 :
                    req="";
                    premierWhere=true; 
                    f=0;
                    String se1 = textes_employe.get(1).getText().trim();
                    String se2 = textes_employe.get(2).getText().trim();
                    String se3 = textes_employe.get(3).getText().trim();
                    String se4 = textes_employe.get(4).getText().trim();

                    if(textes_employe.get(0).getText().length() != 0)
                    {
                      f= Integer.parseInt(textes_employe.get(0).getText().trim());
                    }
                    if(se1.compareTo("")==0 && se2.compareTo("")==0 && se3.compareTo("")==0 &&se4.compareTo("")==0 && f==0){ // si aucune saisie 
                        res.removeAll();
                        res.setLayout(new GridLayout(0,2));
                        ArrayList l =rechEmploye(); //on appelle la fonction de base des requete 
                        this.result(l);
                    }

                    else{
                        if(f!=0){
                            req +="'no_employe'='"+f+"'";
                            premierWhere = false;
                        }
                        if(se1.compareTo("")!=0){
                            if(premierWhere==false){
                                req +=" AND ";
                            }
                            req +="'nom'='"+se1+"'";
                            premierWhere = false;
                        }
                        if(se2.compareTo("")!=0){
                            if(premierWhere==false){
                                req +=" AND ";
                            }
                            req +="'prenom'='"+se2+"'";
                            premierWhere = false;
                        }
                        if(se3.compareTo("")!=0){
                            if(premierWhere==false){
                                req +=" AND ";
                            }
                            req +="'adresse'='"+se3+"'";
                            premierWhere = false;
                        }
                        if(se4.compareTo("")!=0){
                            if(premierWhere==false){
                                req +=" AND ";
                            }
                            req +="'no_telephone'='"+se4+"'";
                            premierWhere = false;
                        }
                        ArrayList list = this.reqEmploye("'employe'",req);
                        res.removeAll();
                        res.setLayout(new GridLayout(0,2));
                        this.result(list);
                    }

                    break;
                case 5 : 
                    req="";
                    a=c=g=0;
                    premierWhere=true; 
                    String sh1 = textes_hospitalisation.get(1).getText().trim();
                        
                        if(textes_hospitalisation.get(0).getText().length() != 0)
                        {
                          a= Integer.parseInt(textes_hospitalisation.get(0).getText().trim());
                        }
                        if(textes_hospitalisation.get(2).getText().length() != 0)
                        {
                          c= Integer.parseInt(textes_hospitalisation.get(2).getText().trim());
                        }
                        if(textes_hospitalisation.get(3).getText().length() != 0)
                        {
                          g= Integer.parseInt(textes_hospitalisation.get(3).getText().trim());
                        }
                        
                        if(sh1.compareTo("")==0 && a==0 && c==0 && g==0) // si aucune saisie
                        {  
                            res.removeAll();
                            res.setLayout(new GridLayout(0,2));
                            ArrayList l =rechHospitalisation(); //on appelle la fonction de base des requete 
                            this.result(l);
                        }
                        else{
                            if(a!=0)
                            {
                                req +="'no_malade'='"+a+"'";
                                premierWhere = false;
                            }
                            if(c!=0){
                                if(premierWhere==false){
                                    req +=" AND ";
                                }
                                req +="'no_chambre'='"+c+"'";
                                premierWhere = false;
                            }
                            if(g!=0){
                                if(premierWhere==false){
                                    req +=" AND ";
                                }
                                req +="'lit'='"+h+"'";
                                premierWhere = false;
                            }
                            if(sh1.compareTo("")!=0){
                                if(premierWhere==false){
                                    req +=" AND ";
                                }
                                req +="'code_service'='"+sh1+"'";
                                premierWhere = false;
                            }
                            ArrayList list = this.reqHospitalisation("'hospitalisation'",req);
                            res.removeAll();
                            res.setLayout(new GridLayout(0,2));
                            this.result(list);
                            
                        }


                    break;
                case 6 : 
                    req="";
                    f=0;
                    premierWhere=true; 

                    String sd1 = textes_docteur.get(1).getText().trim();
                    if(textes_docteur.get(0).getText().length() != 0)
                    {
                       f= Integer.parseInt(textes_docteur.get(0).getText().trim());
                    }

                    if(sd1.compareTo("")==0 && f==0) // si aucune saisie
                    {  
                        res.removeAll();
                        res.setLayout(new GridLayout(0,2));
                        ArrayList l =rechDocteur(); //on appelle la fonction de base des requete 
                        this.result(l);

                    }
                    else{
                        if(f!=0)
                        {
                            req +="'no_docteur'='"+h+"'";
                            premierWhere = false;
                        }
                        if(sd1.compareTo("")!=0){
                            if(premierWhere==false){
                                req +=" AND ";
                            }
                            req +="'specialite'='"+sd1+"'";
                            premierWhere = false;
                        }
                            
                        ArrayList list = this.reqDocteur("'docteur'",req);
                        res.removeAll();
                        res.setLayout(new GridLayout(0,2));
                        this.result(list);

                    }
                    break;
                case 7 : 
                    req="";
                    premierWhere=true; 
                    f=0;
                    String si1 = textes_infirmier.get(1).getText().trim();
                    String si2 = textes_infirmier.get(2).getText().trim();
                    String si3 = textes_infirmier.get(3).getText().trim();

                    if(textes_infirmier.get(0).getText().length() != 0){
                            f= Integer.parseInt(textes_infirmier.get(0).getText().trim());
                            }
                    if(si1.compareTo("")==0 && si2.compareTo("")==0 && si3.compareTo("")==0 && f==0){ // si aucune saisie 
                        res.removeAll();
                        res.setLayout(new GridLayout(0,2));
                        ArrayList l =rechInfirmier(); //on appelle la fonction de base des requete 
                        this.result(l);

                    }
                    else{
                        if(f!=0){
                            req +="'no_infirmier'='"+f+"'";
                            premierWhere = false;

                             }
                        if(si1.compareTo("")!=0){
                            if(premierWhere==false){
                                req +=" AND ";
                            }
                            req +="'nom'='"+si1+"'";
                            premierWhere = false;
                        }
                        if(si2.compareTo("")!=0){
                            if(premierWhere==false){
                                req +=" AND ";
                            }
                            req +="'prenom'='"+si2+"'";
                            premierWhere = false;
                        }
                        if(si3.compareTo("")!=0){
                            if(premierWhere==false){
                                req +=" AND ";
                            }
                            req +="'adresse'='"+si3+"'";
                            premierWhere = false;
                            }
                        ArrayList list = this.reqInfirmier("'infirmier'",req);
                        res.removeAll();
                        res.setLayout(new GridLayout(0,2));
                        this.result(list);
                    }
                    break;
                default :
                    break;
            }   
        }
    }
}
