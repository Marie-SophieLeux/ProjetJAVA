/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vue;

import Modele.Connexion;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;


/**
 *
 * @author Merlo
 */
public class ReqEnr extends JFrame implements ActionListener {
    private Connexion co;
    private JButton btn_reqEnr;
    private JPanel pan1;
    private JLabel lab1;
    private JComboBox cbB1;
    private JScrollPane scroll;
    
    public ReqEnr(Connexion co){
        super();
        this.co=co;
        getContentPane().setLayout(new BorderLayout());
        this.setTitle("Fenêtre de requêtes enregistrées");
        this.setSize(800, 800);
        
        //creation fenetre affichage
        
        
        pan1 = new JPanel(new GridLayout(0,4)); 
        scroll = new JScrollPane(pan1,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        
        scroll.setLayout(new ScrollPaneLayout());
        scroll.setSize(new Dimension(300, 300));
        
        //creation de la liste déroulante et ajout des items 
        cbB1 = new JComboBox();
        cbB1.addItem("Requete n°1");
        cbB1.addItem("Requete n°2");
        cbB1.addItem("Requete n°3");
        cbB1.addItem("Requete n°4");
        cbB1.addItem("Requete n°5");
        cbB1.addItem("Requete n°6");
        cbB1.addItem("Requete n°7");
        cbB1.addItem("Requete n°8");
        cbB1.addItem("Requete n°9");
        cbB1.addItem("Requete n°10");
        
        //text erreur 
        lab1 = new JLabel();
        
        //bouton d'execution
        btn_reqEnr = new JButton("Executer la requêt sélectionnée");
        
        this.getContentPane().add(cbB1,BorderLayout.WEST);
        this.getContentPane().add(scroll,BorderLayout.CENTER);
        this.getContentPane().add(btn_reqEnr,BorderLayout.SOUTH);
        this.getContentPane().add(lab1,BorderLayout.NORTH);
        this.setVisible(true);
        
        //
        
    }
//ajout des resultats au pan de resultats 
    public void result(ArrayList l){
        String str="";
        for(int i=0;i<l.size();i++){
            str = l.get(i).toString();
            pan1.add(new JLabel(str));
            str= "";
        }
            
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ArrayList<String> resultat = new ArrayList<String>();
        Object source = e.getSource();
        if(source==btn_reqEnr){
            //textArea1.append((String)cbB1.getSelectedItem()+"\n"); 
            if(cbB1.getSelectedIndex()==0){
                try {
                    pan1.removeAll();
                    resultat=co.remplirChampsRequete(co.requetes.get(0).trim());
                    this.result(resultat);
                    pan1.repaint();
                } catch (SQLException ex) {
                    System.out.println("echec sql");
                    Logger.getLogger(ReqEnr.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            if(cbB1.getSelectedIndex()==1){
                try {
                    resultat=co.remplirChampsRequete(co.requetes.get(1).trim());
                    this.result(resultat);
                } catch (SQLException ex) {
                    Logger.getLogger(ReqEnr.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            if(cbB1.getSelectedIndex()==2){
                try {
                    resultat=co.remplirChampsRequete(co.requetes.get(2).trim());
                    this.result(resultat);
                } catch (SQLException ex) {
                    Logger.getLogger(ReqEnr.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            if(cbB1.getSelectedIndex()==3){
                try {
                    resultat=co.remplirChampsRequete(co.requetes.get(3).trim());
                    this.result(resultat);
                } catch (SQLException ex) {
                    Logger.getLogger(ReqEnr.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            if(cbB1.getSelectedIndex()==4){
                try {
                    resultat=co.remplirChampsRequete(co.requetes.get(4).trim());
                    this.result(resultat);
                } catch (SQLException ex) {
                    Logger.getLogger(ReqEnr.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            if(cbB1.getSelectedIndex()==5){
                try {
                    resultat=co.remplirChampsRequete(co.requetes.get(5).trim());
                    this.result(resultat);
                } catch (SQLException ex) {
                    Logger.getLogger(ReqEnr.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            if(cbB1.getSelectedIndex()==6){
                try {
                    resultat=co.remplirChampsRequete(co.requetes.get(6).trim());
                    this.result(resultat);
                } catch (SQLException ex) {
                    Logger.getLogger(ReqEnr.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            if(cbB1.getSelectedIndex()==7){
                try {
                    resultat=co.remplirChampsRequete(co.requetes.get(7).trim());
                    this.result(resultat);
                } catch (SQLException ex) {
                    Logger.getLogger(ReqEnr.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            if(cbB1.getSelectedIndex()==8){
                try {
                    resultat=co.remplirChampsRequete(co.requetes.get(8).trim());
                    this.result(resultat);
                } catch (SQLException ex) {
                    Logger.getLogger(ReqEnr.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            if(cbB1.getSelectedIndex()==9){
                try {
                    resultat=co.remplirChampsRequete(co.requetes.get(9).trim());
                    this.result(resultat);
                } catch (SQLException ex) {
                    Logger.getLogger(ReqEnr.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            if(cbB1.getSelectedIndex()==-1){
                lab1.setText("Veuillez choisir une requête dans la liste déroulante");
            }
        }
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
