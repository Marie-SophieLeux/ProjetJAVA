/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vue;

import Modele.Connexion;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.ScrollPaneLayout;

/**
 *
 * @author Merlo
 */
public class FenMaj extends JFrame implements ActionListener{
    
   
    private JTabbedPane classe;
    public Connexion co;
    
    ArrayList<JTextField> textes_malade = new ArrayList<JTextField>();
    ArrayList<JTextField> textes_service = new ArrayList<JTextField>();
    ArrayList<JTextField> textes_chambre = new ArrayList<JTextField>();
    ArrayList<JTextField> textes_soin = new ArrayList<JTextField>();
    ArrayList<JTextField> textes_employe = new ArrayList<JTextField>();
    ArrayList<JTextField> textes_hospitalisation = new ArrayList<JTextField>();
    ArrayList<JTextField> textes_docteur = new ArrayList<JTextField>();
    ArrayList<JTextField> textes_infirmier = new ArrayList<JTextField>();
    
    private JPanel pan1,pan2,pan3,pan4,pan5,pan6,pan7,pan8,panA,res,panB;
    private JButton add,supp,mod;
    private JScrollPane scroll;
   
    public FenMaj(Connexion co){
        this.co=co;
        getContentPane().setLayout(new BorderLayout());
        //this.setLocationRelativeTo(null);
        this.setTitle("Fenêtre de Mise à jour");
        this.setSize(800, 800);
        
       
        classe = new JTabbedPane();
        
        panA = new JPanel();
        panA.setLayout(new BorderLayout());
        
        pan1 = new JPanel();
        pan2 = new JPanel();
        pan3 = new JPanel();
        pan4 = new JPanel();
        pan5 = new JPanel();
        pan6 = new JPanel();
        pan7 = new JPanel();
        pan8 = new JPanel();
        
        res = new JPanel();
        panB = new JPanel();
        
        
        malade();
        service();
        chambre();
        soin();
        employe();
        hospitalisation();
        docteur();
        infirmier();

        classe.add("Malade", pan1);
        classe.add("Service", pan2);
        classe.add("Chambre", pan3);
        classe.add("Soin", pan4);
        classe.add("Employé", pan5);
        classe.add("Hospitalisation", pan6);
        classe.add("Docteur", pan7);
        classe.add("Infirmier", pan8);
        
        add = new JButton("Ajouter");
        supp = new JButton("Supprimer");
        mod = new JButton("Modifier");
        
        add.addActionListener(this);
        mod.addActionListener(this);
        supp.addActionListener(this);
        
        JPanel panB1 = new JPanel(new GridLayout(1,3));
        panB1.add(add);
        panB1.add(mod);
        panB1.add(supp);
        panA.add(classe, BorderLayout.NORTH);
        
        //affichage resultat 
        
        res.setBackground(Color.WHITE);
        scroll = new JScrollPane(res,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        
        scroll.setLayout(new ScrollPaneLayout());
        scroll.setSize(new Dimension(300, 300));
  
        getContentPane().add(panA);
        
        getContentPane().add(panB1,BorderLayout.SOUTH);
        
        this.setVisible(true);
    }
    
    public void malade(){
        pan1.setLayout(new GridLayout(3,2));
        JLabel label1 = new JLabel("Numero");
        JLabel label2 = new JLabel("Nom");
        JLabel label3 = new JLabel("Prenom");
	JLabel label4 = new JLabel("Adresse");
	JLabel label5 = new JLabel("Telephone");
	JLabel label6 = new JLabel("Mutuelle");
        
        JTextField text1 = new JTextField();
	JTextField text2 = new JTextField();
	JTextField text3 = new JTextField();
	JTextField text4 = new JTextField();
	JTextField text5 = new JTextField();
	JTextField text6 = new JTextField();
        
        text1.setPreferredSize(new Dimension(100,20));
        text1.setPreferredSize(new Dimension(100,20));
        text2.setPreferredSize(new Dimension(100,20));
        text3.setPreferredSize(new Dimension(100,20));
        text4.setPreferredSize(new Dimension(100,20));
        text5.setPreferredSize(new Dimension(100,20));
        text6.setPreferredSize(new Dimension(100,20));
        
        
        JPanel p1 = new JPanel();
	JPanel p2 = new JPanel();
	JPanel p3 = new JPanel();
	JPanel p4 = new JPanel();
	JPanel p5 = new JPanel();
	JPanel p6 = new JPanel();
        
        textes_malade.add(text1);
        textes_malade.add(text2);
        textes_malade.add(text3);
        textes_malade.add(text4);
        textes_malade.add(text5);
        textes_malade.add(text6);
        
        p1.add(label1);
        p1.add(text1);
        p2.add(label2);
        p2.add(text2);
        p3.add(label3);
        p3.add(text3);
        p4.add(label4);
        p4.add(text4);
        p5.add(label5);
        p5.add(text5);
        p6.add(label6);
        p6.add(text6);
        
        pan1.add(p1);
        pan1.add(p2);
        pan1.add(p3);
        pan1.add(p4);
        pan1.add(p5);
        pan1.add(p6);
     } 
    public void service(){
        pan2.setLayout(new GridLayout(2,4));
        JLabel label1 = new JLabel("Code");
        JLabel label2 = new JLabel("Nom");
        JLabel label3 = new JLabel("Batiment");
	JLabel label4 = new JLabel("Directeur");

        
        JTextField text1 = new JTextField();
	JTextField text2 = new JTextField();
	JTextField text3 = new JTextField();
	JTextField text4 = new JTextField();
	
        text1.setPreferredSize(new Dimension(100,20));
        text2.setPreferredSize(new Dimension(100,20));
        text3.setPreferredSize(new Dimension(100,20));
        text4.setPreferredSize(new Dimension(100,20));
        
        JPanel p1 = new JPanel();
	JPanel p2 = new JPanel();
	JPanel p3 = new JPanel();
	JPanel p4 = new JPanel();
	
        
        textes_service.add(text1);
        textes_service.add(text2);
        textes_service.add(text3);
        textes_service.add(text4);
    
        
        p1.add(label1);
        p1.add(text1);
        p2.add(label2);
        p2.add(text2);
        p3.add(label3);
        p3.add(text3);
        p4.add(label4);
        p4.add(text4);
   
        pan2.add(p1);
        pan2.add(p2);
        pan2.add(p3);
        pan2.add(p4);
   
     } 
    public void chambre(){
        pan3.setLayout(new GridLayout(2,4));
        JLabel label1 = new JLabel("Code Service");
        JLabel label2 = new JLabel("Numero chambre");
        JLabel label3 = new JLabel("Surveillant");
	JLabel label4 = new JLabel("Nombre lit");

        
        JTextField text1 = new JTextField();
	JTextField text2 = new JTextField();
	JTextField text3 = new JTextField();
	JTextField text4 = new JTextField();

        text1.setPreferredSize(new Dimension(100,20));
        text2.setPreferredSize(new Dimension(100,20));
        text3.setPreferredSize(new Dimension(100,20));
        text4.setPreferredSize(new Dimension(100,20));
        
        JPanel p1 = new JPanel();
	JPanel p2 = new JPanel();
	JPanel p3 = new JPanel();
	JPanel p4 = new JPanel();

        
        textes_chambre.add(text1);
        textes_chambre.add(text2);
        textes_chambre.add(text3);
        textes_chambre.add(text4);
      
        
        p1.add(label1);
        p1.add(text1);
        p2.add(label2);
        p2.add(text2);
        p3.add(label3);
        p3.add(text3);
        p4.add(label4);
        p4.add(text4);
    
        pan3.add(p1);
        pan3.add(p2);
        pan3.add(p3);
        pan3.add(p4);
   
    } 
    public void soin(){
        pan4.setLayout(new GridLayout(1,2));
        JLabel label1 = new JLabel("Numero Docteur");
	JLabel label2 = new JLabel("Numero Malade");
        
        JTextField text1 = new JTextField();
	JTextField text2 = new JTextField();
        
        text1.setPreferredSize(new Dimension(100,20));
        text2.setPreferredSize(new Dimension(100,20));
        
        JPanel p1 = new JPanel();
	JPanel p2 = new JPanel();
        
        textes_soin.add(text1);
        textes_soin.add(text2);
        
        p1.add(label1);
        p1.add(text1);
        p2.add(label2);
        p2.add(text2);
        
        pan4.add(p1);
        pan4.add(p2);
    }
    public void employe(){
        pan5.setLayout(new GridLayout(3,4));
        JLabel label1 = new JLabel("Numero");
        JLabel label2 = new JLabel("Nom");
        JLabel label3 = new JLabel("Prenom");
	JLabel label4 = new JLabel("Adresse");
	JLabel label5 = new JLabel("Telephone");
        
        JTextField text1 = new JTextField();
	JTextField text2 = new JTextField();
	JTextField text3 = new JTextField();
	JTextField text4 = new JTextField();
	JTextField text5 = new JTextField();
        
        text1.setPreferredSize(new Dimension(100,20));
        text2.setPreferredSize(new Dimension(100,20));
        text3.setPreferredSize(new Dimension(100,20));
        text4.setPreferredSize(new Dimension(100,20));
        text5.setPreferredSize(new Dimension(100,20));
        
        JPanel p1 = new JPanel();
	JPanel p2 = new JPanel();
	JPanel p3 = new JPanel();
	JPanel p4 = new JPanel();
	JPanel p5 = new JPanel();
	
        
        textes_employe.add(text1);
        textes_employe.add(text2);
        textes_employe.add(text3);
        textes_employe.add(text4);
        textes_employe.add(text5);
        
        p1.add(label1);
        p1.add(text1);
        p2.add(label2);
        p2.add(text2);
        p3.add(label3);
        p3.add(text3);
        p4.add(label4);
        p4.add(text4);
        p5.add(label5);
        p5.add(text5);
      
        
        pan5.add(p1);
        pan5.add(p2);
        pan5.add(p3);
        pan5.add(p4);
        pan5.add(p5);
           
    }
    public void hospitalisation(){
        pan6.setLayout(new GridLayout(2,4));
        JLabel label1 = new JLabel("Numero malade");
        JLabel label2 = new JLabel("Code service");
        JLabel label3 = new JLabel("Numero chambre");
	JLabel label4 = new JLabel("Lit");
	
        
        JTextField text1 = new JTextField();
	JTextField text2 = new JTextField();
	JTextField text3 = new JTextField();
	JTextField text4 = new JTextField();
        
        
        text1.setPreferredSize(new Dimension(100,20));
        text2.setPreferredSize(new Dimension(100,20));
        text3.setPreferredSize(new Dimension(100,20));
        text4.setPreferredSize(new Dimension(100,20));
        
        
        JPanel p1 = new JPanel();
	JPanel p2 = new JPanel();
	JPanel p3 = new JPanel();
	JPanel p4 = new JPanel();
        
        textes_hospitalisation.add(text1);
        textes_hospitalisation.add(text2);
        textes_hospitalisation.add(text3);
        textes_hospitalisation.add(text4);
        
        p1.add(label1);
        p1.add(text1);
        p2.add(label2);
        p2.add(text2);
        p3.add(label3);
        p3.add(text3);
        p4.add(label4);
        p4.add(text4);
        
        pan6.add(p1);
        pan6.add(p2);
        pan6.add(p3);
        pan6.add(p4);
    } 
    public void docteur(){
        pan7.setLayout(new GridLayout(1,2));
        JLabel label1 = new JLabel("Numero ");
	JLabel label2 = new JLabel("Specialité");
        
        JTextField text1 = new JTextField();
	JTextField text2 = new JTextField();
        
        text1.setPreferredSize(new Dimension(100,20));
        text2.setPreferredSize(new Dimension(100,20));
        
        JPanel p1 = new JPanel();
	JPanel p2 = new JPanel();
        
        textes_docteur.add(text1);
        textes_docteur.add(text2);
        
        p1.add(label1);
        p1.add(text1);
        p2.add(label2);
        p2.add(text2);
        
        pan7.add(p1);
        pan7.add(p2);
    }
    public void infirmier(){
        pan8.setLayout(new GridLayout(3,4));
        JLabel label1 = new JLabel("Numero");
        JLabel label2 = new JLabel("Nom");
        JLabel label3 = new JLabel("Prenom");
	JLabel label4 = new JLabel("Adresse");
        
        JTextField text1 = new JTextField();
	JTextField text2 = new JTextField();
	JTextField text3 = new JTextField();
	JTextField text4 = new JTextField();
        
        text1.setPreferredSize(new Dimension(100,20));
        text2.setPreferredSize(new Dimension(100,20));
        text3.setPreferredSize(new Dimension(100,20));
        text4.setPreferredSize(new Dimension(100,20));
        
        JPanel p1 = new JPanel();
	JPanel p2 = new JPanel();
	JPanel p3 = new JPanel();
	JPanel p4 = new JPanel();
	
        
        textes_infirmier.add(text1);
        textes_infirmier.add(text2);
        textes_infirmier.add(text3);
        textes_infirmier.add(text4);
        
        p1.add(label1);
        p1.add(text1);
        p2.add(label2);
        p2.add(text2);
        p3.add(label3);
        p3.add(text3);
        p4.add(label4);
        p4.add(text4);
      
        
        pan8.add(p1);
        pan8.add(p2); 
        pan8.add(p3);
        pan8.add(p4);
    }
    
    //ajout des resultats au pan de resultats 
    public void result(ArrayList l){
        String str="";
        for(int i=0;i<l.size();i++){
            str = l.get(i).toString();
            res.add(new JLabel(str));
            str= "";
        }
            
    }
    
    
    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        
        //variables utilisées pour recupérer les entiers 
        int a=0; // numero du malade  
        int b=0; // numero directeur service
        int c=0; // numero chambre
        int d= 0; // nombre lits
        int h=0; // numero doc
        int f=0; // num employe
        int g=0; // numero lit
        
        int index = classe.getSelectedIndex();
        if(source==add){
            String table="";
            String req="";
            if(index==0){ // table malade
                table="malade";
                //ajout d'un nouveau malade grace aux infomations fournies par l'utilisateur
                String s0 = textes_malade.get(0).getText().trim();
                String s1 = textes_malade.get(2).getText().trim();
                String s2 = textes_malade.get(3).getText().trim();
                String s3 = textes_malade.get(4).getText().trim();
                String s4 = textes_malade.get(5).getText().trim();
                String s5 = textes_malade.get(1).getText().trim();
                
                if(s0.compareTo("")!=0 && s1.compareTo("")!=0 && s2.compareTo("")!=0 && s3.compareTo("")!=0 && s4.compareTo("")!=0 && s5.compareTo("")!=0){
                    req="";
                    res.setLayout(new GridLayout(0,2));
                    res.removeAll();
                    ArrayList<String> liste = new ArrayList<String>();
                    req = "INSERT INTO `malade`" + "VALUES('"+s0+"','"+s1+"','"+s2+"','"+s3+"','"+s4+"','"+s5+"')";
                    try {
                        liste = co.remplirChampsRequete(req);
                        result(liste);
                    } catch (SQLException ex) {
                        System.out.println("Erreur SQL Add");
                        //Logger.getLogger(FenMaj.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                else {
                    System.out.println("Veuillez entrer tous les champs");
                }
            }
            if(index ==1){ //table service
                table="service";
                //ajout d'un nouveau service à la BDD selon les informations saisies par l'utilisateur
                String st0 = textes_service.get(3).getText().trim();
                String st1 = textes_service.get(0).getText().trim();
                String st2 = textes_service.get(1).getText().trim();
                String st3 = textes_service.get(2).getText().trim();
                
                if(st0.compareTo("")!=0 && st1.compareTo("")!=0 && st2.compareTo("")!=0 && st3.compareTo("")!=0){
                    req="";
                    res.setLayout(new GridLayout(0,2));
                    res.removeAll();
                    ArrayList<String> liste = new ArrayList<String>();
                    req = "INSERT INTO `service`" + "VALUES('"+st0+"','"+st1+"','"+st2+"','"+st3+"')";
                    try {
                        liste = co.remplirChampsRequete(req);
                        result(liste);
                    } catch (SQLException ex) {
                        System.out.println("Erreur SQL Add");
                        //Logger.getLogger(FenMaj.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                else {
                    System.out.println("Veuillez entrer tous les champs ");
                }
            }
            if(index ==2){ //table chambre
                table="chambre";
                //ajout d'une nouvelle chambre à la BDD selon les informations saisies par l'utilisateur
                String st0 = textes_chambre.get(3).getText().trim(); //code service
                String st1 = textes_chambre.get(0).getText().trim(); //no_chambre
                String st2 = textes_chambre.get(1).getText().trim(); //surveillant
                String st3 = textes_chambre.get(2).getText().trim(); //nb_lits
                if(st0.compareTo("")!=0 && st1.compareTo("")!=0 && st2.compareTo("")!=0 && st3.compareTo("")!=0){
                    req="";
                    res.setLayout(new GridLayout(0,2));
                    res.removeAll();
                    ArrayList<String> liste = new ArrayList<String>();
                    req = "INSERT INTO `chambre`" + "VALUES('"+st0+"','"+st1+"','"+st2+"','"+st3+"')";
                    try {
                        liste = co.remplirChampsRequete(req);
                        result(liste);
                    } catch (SQLException ex) {
                        System.out.println("Erreur SQL Add");
                        //Logger.getLogger(FenMaj.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                else {
                    System.out.println("Veuillez entrer tous les champs ");
                }
            }
            
            
            if(index ==3){ //table soin
                table="soin";
                //ajout d'un nouveau soin réalisé à la BDD selon les informations saisies par l'utilisateur
                String st0 = textes_chambre.get(3).getText().trim(); //no_docteur
                String st1 = textes_chambre.get(0).getText().trim(); //no_malade
                if(st0.compareTo("")!=0 && st1.compareTo("")!=0){
                    req="";
                    res.setLayout(new GridLayout(0,2));
                    res.removeAll();
                    ArrayList<String> liste = new ArrayList<String>();
                    req = "INSERT INTO `soin`" + "VALUES('"+st0+"','"+st1+"')";
                    try {
                        liste = co.remplirChampsRequete(req);
                        result(liste);
                    } catch (SQLException ex) {
                        System.out.println("Erreur SQL Add");
                        //Logger.getLogger(FenMaj.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                else {
                    System.out.println("Veuillez entrer tous les champs ");
                }
            }
            
            
            if(index ==4){ //table employé
                table="employe";
                // ajout d'un nouvel employe selon les informations saisies par l'utilisateur
                String se0 = textes_employe.get(0).getText().trim();
                String se1 = textes_employe.get(1).getText().trim();
                String se2 = textes_employe.get(2).getText().trim();
                String se3 = textes_employe.get(3).getText().trim();
                String se4 = textes_employe.get(4).getText().trim();
                if(se0.compareTo("")!=0 && se1.compareTo("")!=0 && se2.compareTo("")!=0 && se3.compareTo("")!=0 && se4.compareTo("")!=0){
                    req="";
                    res.setLayout(new GridLayout(0,2));
                    res.removeAll();
                    ArrayList<String> liste = new ArrayList<String>();
                    req = "INSERT INTO `employe`" + "VALUES('"+se0+"','"+se1+"','"+se2+"','"+se3+"','"+se4+"')";
                    try {
                        liste = co.remplirChampsRequete(req);
                        result(liste);
                    } catch (SQLException ex) {
                        System.out.println("Erreur SQL Add");
                        //Logger.getLogger(FenMaj.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                else {
                    System.out.println("Veuillez entrer tous les champs ");
                }
            }
            
            
            if(index ==5){ //table hospitalisation
                table="hospitalisation";
                // ajout d'une nouvelle hospitalisation selon les informations saisies par l'utilisateur
                String sh0 = textes_hospitalisation.get(0).getText().trim();
                String sh1 = textes_hospitalisation.get(1).getText().trim();
                String sh2 = textes_hospitalisation.get(2).getText().trim();
                String sh3 = textes_hospitalisation.get(3).getText().trim();
                if(sh0.compareTo("")!=0 && sh1.compareTo("")!=0 && sh2.compareTo("")!=0 && sh3.compareTo("")!=0){
                    req="";
                    res.setLayout(new GridLayout(0,2));
                    res.removeAll();
                    ArrayList<String> liste = new ArrayList<String>();
                    req = "INSERT INTO `hospitalisation`" + "VALUES('"+sh0+"','"+sh1+"','"+sh2+"','"+sh3+"')";
                    try {
                        liste = co.remplirChampsRequete(req);
                        result(liste);
                    } catch (SQLException ex) {
                        System.out.println("Erreur SQL Add");
                        //Logger.getLogger(FenMaj.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                else {
                    System.out.println("Veuillez entrer tous les champs ");
                }
            }
            
            if(index ==6){ //table docteur
                table="docteur";
                // ajout d'un nouveau docteur selon les informations saisies par l'utilisateur
                String sd0 = textes_hospitalisation.get(0).getText().trim();
                String sd1 = textes_hospitalisation.get(1).getText().trim();
                if(sd0.compareTo("")!=0 && sd1.compareTo("")!=0){
                    req="";
                    res.setLayout(new GridLayout(0,2));
                    res.removeAll();
                    ArrayList<String> liste = new ArrayList<String>();
                    req = "INSERT INTO `docteur`" + "VALUES('"+sd0+"','"+sd1+"')";
                    try {
                        liste = co.remplirChampsRequete(req);
                        result(liste);
                    } catch (SQLException ex) {
                        System.out.println("Erreur SQL Add");
                        //Logger.getLogger(FenMaj.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                else {
                    System.out.println("Veuillez entrer tous les champs ");
                }
            }
            
            if(index ==7){ //table infirmier
                table="infirmier";
                // ajout d'un nouvel infirmier selon les informations saisies par l'utilisateur
                String si0 = textes_infirmier.get(0).getText().trim();
                String si1 = textes_service.get(1).getText().trim();
                String si2 = textes_service.get(2).getText().trim();
                String si3 = textes_service.get(3).getText().trim();
                if(si0.compareTo("")!=0 && si1.compareTo("")!=0 && si2.compareTo("")!=0 && si3.compareTo("")!=0){
                    req="";
                    res.setLayout(new GridLayout(0,2));
                    res.removeAll();
                    ArrayList<String> liste = new ArrayList<String>();
                    req = "INSERT INTO `infirmier`" + "VALUES('"+si0+"','"+si1+"','"+si2+"','"+si3+"')";
                    try {
                        liste = co.remplirChampsRequete(req);
                        result(liste);
                    } catch (SQLException ex) {
                        System.out.println("Erreur SQL Add");
                        //Logger.getLogger(FenMaj.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                else {
                    System.out.println("Veuillez entrer tous les champs ");
                }
            }
        }
        if(source==supp){
            String req="";
            switch(index){ 
                
                case 0: // table malade
                req="";    
                a=0;
                if(textes_malade.get(0).getText().length()!=0){
                    a=Integer.parseInt(textes_malade.get(0).getText().trim());
                }
                if(a!=0){
                    
                    res.setLayout(new GridLayout(0,2));
                    res.removeAll();
                    ArrayList<String> liste = new ArrayList<String>();
                    req = "DELETE FROM `malade` WHERE `numero`="+a;
                    try {
                        liste = co.remplirChampsRequete(req);
                        result(liste);
                    } catch (SQLException ex) {
                        System.out.println("Erreur SQL Update");
                        //Logger.getLogger(FenMaj.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                else {
                   // System.out.println("Veuillez entrer tous les champs ");
                }
                
                case 1 : // table service
                    req="";
                    String code_s = textes_service.get(0).getText().trim();
                    if(code_s.compareTo("")!=0)
                    {
                        res.setLayout(new GridLayout(0,2));
                    res.removeAll();
                    ArrayList<String> liste = new ArrayList<String>();
                    req = "DELETE FROM `service` WHERE `code`="+code_s;
                    try {
                        liste = co.remplirChampsRequete(req);
                        result(liste);
                    } catch (SQLException ex) {
                        System.out.println("Erreur SQL Update");
                        //Logger.getLogger(FenMaj.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                else {
                   // System.out.println("Veuillez entrer tous les champs ");
                }
                
                case 2: // table chambre
                    req="";
                    c=0;
                    if(textes_chambre.get(1).getText().length()!=0){
                    a=Integer.parseInt(textes_chambre.get(1).getText().trim());
                }
                if(c!=0){
                    
                    res.setLayout(new GridLayout(0,2));
                    res.removeAll();
                    ArrayList<String> liste = new ArrayList<String>();
                    req = "DELETE FROM `chambre` WHERE `no_chambre`="+c;
                    try {
                        liste = co.remplirChampsRequete(req);
                        result(liste);
                    } catch (SQLException ex) {
                        System.out.println("Erreur SQL Update");
                        //Logger.getLogger(FenMaj.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                else {
                   // System.out.println("Veuillez entrer tous les champs ");
                }
                
                case 3: // table soin
                    req="";
                    a=h=0;
                    if(textes_soin.get(0).getText().length()!=0){
                       h=Integer.parseInt(textes_soin.get(0).getText().trim());
                    }
                    if(textes_soin.get(1).getText().length()!=0){
                       a=Integer.parseInt(textes_soin.get(1).getText().trim());
                    }
                    if(a!=0 && h!=0){
                    
                    res.setLayout(new GridLayout(0,2));
                    res.removeAll();
                    ArrayList<String> liste = new ArrayList<String>();
                    req = "DELETE FROM `soigne` WHERE `no_docteur`="+h +"AND 'no_malade="+a;
                    try {
                        liste = co.remplirChampsRequete(req);
                        result(liste);
                    } catch (SQLException ex) {
                        System.out.println("Erreur SQL Update");
                        //Logger.getLogger(FenMaj.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                else {
                   // System.out.println("Veuillez entrer tous les champs ");
                }
                 
                case 4 : // table employe
                    req="";
                    f=0;
                     if(textes_employe.get(0).getText().length() != 0)
                    {
                      f= Integer.parseInt(textes_employe.get(0).getText().trim());
                    }
                    if(f!=0){
                    
                    res.setLayout(new GridLayout(0,2));
                    res.removeAll();
                    ArrayList<String> liste = new ArrayList<String>();
                    req = "DELETE FROM `employe` WHERE `numero`="+f;
                    try {
                        liste = co.remplirChampsRequete(req);
                        result(liste);
                    } catch (SQLException ex) {
                        System.out.println("Erreur SQL Update");
                        //Logger.getLogger(FenMaj.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                else {
                   // System.out.println("Veuillez entrer tous les champs ");
                }
                  
                case 5 : // table hospitalisation
                    req="";
                    if(textes_hospitalisation.get(0).getText().length() != 0)
                        {
                          a= Integer.parseInt(textes_hospitalisation.get(0).getText().trim());
                        }
                    if(a!=0){
                    
                    res.setLayout(new GridLayout(0,2));
                    res.removeAll();
                    ArrayList<String> liste = new ArrayList<String>();
                    req = "DELETE FROM `hospitalisation` WHERE `no_malade`="+a;
                    try {
                        liste = co.remplirChampsRequete(req);
                        result(liste);
                    } catch (SQLException ex) {
                        System.out.println("Erreur SQL Update");
                        //Logger.getLogger(FenMaj.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                else {
                   // System.out.println("Veuillez entrer tous les champs ");
                }
                   
                case 6 : // table docteur
                    req="";
                    h=0;
                    if(textes_docteur.get(0).getText().length() != 0)
                    {
                       h= Integer.parseInt(textes_docteur.get(0).getText().trim());
                    }
                    if(h!=0){
                    
                    res.setLayout(new GridLayout(0,2));
                    res.removeAll();
                    ArrayList<String> liste = new ArrayList<String>();
                    req = "DELETE FROM `docteur` WHERE `numero`="+h;
                    try {
                        liste = co.remplirChampsRequete(req);
                        result(liste);
                    } catch (SQLException ex) {
                        System.out.println("Erreur SQL Update");
                        //Logger.getLogger(FenMaj.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                else {
                   // System.out.println("Veuillez entrer tous les champs ");
                }
                    
                case 7: // table infirmier
                    req="";
                    f=0;
                     if(textes_infirmier.get(0).getText().length() != 0){
                            f= Integer.parseInt(textes_infirmier.get(0).getText().trim());
                            }
                     if(f!=0){
                    
                    res.setLayout(new GridLayout(0,2));
                    res.removeAll();
                    ArrayList<String> liste = new ArrayList<String>();
                    req = "DELETE FROM `infirmier` WHERE `numero`="+f;
                    try {
                        liste = co.remplirChampsRequete(req);
                        result(liste);
                    } catch (SQLException ex) {
                        System.out.println("Erreur SQL Update");
                        //Logger.getLogger(FenMaj.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                else {
                   // System.out.println("Veuillez entrer tous les champs ");
                }
                    
                    
                    
            }
        }
        
        if(source==mod){
            String table="";
            String req="";
            if(index==0){ // table malade
                table="malade";
                a=0;
                String s1 = textes_malade.get(2).getText().trim();
                String s2 = textes_malade.get(3).getText().trim();
                String s3 = textes_malade.get(4).getText().trim();
                String s4 = textes_malade.get(5).getText().trim();
                String s5 = textes_malade.get(1).getText().trim();
                
                if(textes_malade.get(0).getText().length()!=0){
                    a=Integer.parseInt(textes_malade.get(0).getText().trim());
                }
                if(s1.compareTo("")!=0 && s2.compareTo("")!=0 && s3.compareTo("")!=0 && s4.compareTo("")!=0 && s5.compareTo("")!=0 && a!=0){
                    req="";
                    res.setLayout(new GridLayout(0,2));
                    res.removeAll();
                    ArrayList<String> liste = new ArrayList<String>();
                    req = "UPDATE FROM `malade` SET `nom` = '"+s1+"', "+"`prenom` = '"+s2+"', "+"`adresse` = '"+s3+"', `telephone` = '"+s4+"', `mutuelle` = '"+s5+"' WHERE `numero`="+a;
                    try {
                        liste = co.remplirChampsRequete(req);
                        result(liste);
                    } catch (SQLException ex) {
                        System.out.println("Erreur SQL Update");
                        //Logger.getLogger(FenMaj.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                else {
                    System.out.println("Veuillez entrer tous les champs ");
                }
            }
            if(index ==1){ //table service
                b=0;
                String st1 = textes_service.get(0).getText().trim();
                String st2 = textes_service.get(1).getText().trim();
                String st3 = textes_service.get(2).getText().trim();
                
                if(textes_service.get(3).getText().length()!=0){
                    b=Integer.parseInt(textes_service.get(3).getText().trim());
                }
                if(st1.compareTo("")!=0 && st2.compareTo("")!=0 && st3.compareTo("")!=0 && b!=0){
                    req="";
                    res.setLayout(new GridLayout(0,2));
                    res.removeAll();
                    ArrayList<String> liste = new ArrayList<String>();
                    req = "UPDATE FROM `service` SET `nom` = '"+st1+"', "+"`batiment` = '"+st2+"', "+"`directeur` = "+b+" WHERE `code`='"+st1+"'";
                    try {
                        liste = co.remplirChampsRequete(req);
                        result(liste);
                    } catch (SQLException ex) {
                        System.out.println("Erreur SQL Update");
                        //Logger.getLogger(FenMaj.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                else {
                    System.out.println("Veuillez entrer tous les champs ");
                }
            }
            if(index ==2){ //table chambre
                c=0;
                f=0;
                d=0;
                table="chambre";
                String st1 = textes_chambre.get(0).getText().trim();
                if(textes_chambre.get(1).getText().length()!=0){
                    c=Integer.parseInt(textes_chambre.get(1).getText().trim());
                }
                if(textes_chambre.get(2).getText().length()!=0){
                    c=Integer.parseInt(textes_chambre.get(2).getText().trim());
                }
                if(textes_chambre.get(3).getText().length()!=0){
                    c=Integer.parseInt(textes_chambre.get(3).getText().trim());
                }
                if(st1.compareTo("")!=0 && c!=0 && f!=0 && d!=0){
                    req="";
                    res.setLayout(new GridLayout(0,2));
                    res.removeAll();
                    ArrayList<String> liste = new ArrayList<String>();
                    req = "UPDATE FROM `chambre` SET `code` = '"+st1+"', "+"`surveillant` = "+f+", "+"`nb_lits` = "+d+" WHERE `no_chambre` = "+c;
                    try {
                        liste = co.remplirChampsRequete(req);
                        result(liste);
                    } catch (SQLException ex) {
                        System.out.println("Erreur SQL Update");
                        //Logger.getLogger(FenMaj.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                else {
                    System.out.println("Veuillez entrer tous les champs ");
                }
            }
            
            
            if(index ==3){ //table soin
                a=0;
                h=0;
                table="soin";
                
                if(textes_soin.get(0).getText().length()!=0){
                    h=Integer.parseInt(textes_soin.get(0).getText().trim());
                }
                if(textes_soin.get(1).getText().length()!=0){
                    a=Integer.parseInt(textes_soin.get(1).getText().trim());
                }
                if(h!=0 && a!=0){
                    req="";
                    res.setLayout(new GridLayout(0,2));
                    res.removeAll();
                    ArrayList<String> liste = new ArrayList<String>();
                    req = "UPDATE FROM `soin` SET "+"`no_docteur` = "+h+", `no_malade`= "+a+" WHERE `no_docteur` = "+h+", `no_malade` = "+a;
                    try {
                        liste = co.remplirChampsRequete(req);
                        result(liste);
                    } catch (SQLException ex) {
                        System.out.println("Erreur SQL Update");
                        //Logger.getLogger(FenMaj.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                else {
                    System.out.println("Veuillez entrer tous les champs ");
                }
            }
            
            
            if(index ==4){ //table employé
                f=0;
                table="employe";
                String se1 = textes_employe.get(1).getText().trim();
                String se2 = textes_employe.get(2).getText().trim();
                String se3 = textes_employe.get(3).getText().trim();
                String se4 = textes_employe.get(4).getText().trim();
                if(textes_employe.get(0).getText().length()!=0){
                    f=Integer.parseInt(textes_employe.get(0).getText().trim());
                }
                if(se1.compareTo("")!=0 && se2.compareTo("")!=0 && se3.compareTo("")!=0 && se4.compareTo("")!=0 && f!=0){
                    req="";
                    res.setLayout(new GridLayout(0,2));
                    res.removeAll();
                    ArrayList<String> liste = new ArrayList<String>();
                    req = "UPDATE FROM `employe` SET `nom` = '"+se1+"', `prenom` = '"+se2+"', `adresse`= '"+se3+"', `telephone` = '"+se4+"', WHERE `numero_e` = "+f;
                    try {
                        liste = co.remplirChampsRequete(req);
                        result(liste);
                    } catch (SQLException ex) {
                        System.out.println("Erreur SQL Update");
                        //Logger.getLogger(FenMaj.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                else {
                    System.out.println("Veuillez entrer tous les champs ");
                }
            }
            
            
            if(index ==5){ //table hospitalisation
                a=0;
                c=0;
                g=0;
                table="hospitalisation";
                String st1 = textes_hospitalisation.get(1).getText().trim();
                if(textes_hospitalisation.get(0).getText().length()!=0){
                    a=Integer.parseInt(textes_hospitalisation.get(0).getText().trim());
                }
                if(textes_hospitalisation.get(2).getText().length()!=0){
                    c=Integer.parseInt(textes_hospitalisation.get(2).getText().trim());
                }
                if(textes_hospitalisation.get(3).getText().length()!=0){
                    g=Integer.parseInt(textes_hospitalisation.get(3).getText().trim());
                }
                if(st1.compareTo("")!=0 && a!=0 && c!=0 && g!=0){
                    req="";
                    res.setLayout(new GridLayout(0,2));
                    res.removeAll();
                    ArrayList<String> liste = new ArrayList<String>();
                    req = "UPDATE FROM `hospitalisation` SET `lit`= "+g+", `no_chambre` = "+c+", `code_service` = '"+st1+"' WHERE `no_malade`="+a;
                    try {
                        liste = co.remplirChampsRequete(req);
                        result(liste);
                    } catch (SQLException ex) {
                        System.out.println("Erreur SQL Update");
                        //Logger.getLogger(FenMaj.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                else {
                    System.out.println("Veuillez entrer tous les champs ");
                }
            }
            
            if(index ==6){ //table docteur
                f=0;
                table="docteur";
                String st1 = textes_docteur.get(1).getText().trim();
                
                if(textes_docteur.get(0).getText().length()!=0){
                    f=Integer.parseInt(textes_docteur.get(0).getText().trim());
                }
                if(st1.compareTo("")!=0 && f!=0){
                    req="";
                    res.setLayout(new GridLayout(0,2));
                    res.removeAll();
                    ArrayList<String> liste = new ArrayList<String>();
                    req = "UPDATE FROM `docteur` SET "+"`specialite` = '"+st1+"  WHERE `numero`="+st1;
                    try {
                        liste = co.remplirChampsRequete(req);
                        result(liste);
                    } catch (SQLException ex) {
                        System.out.println("Erreur SQL Update");
                        //Logger.getLogger(FenMaj.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                else {
                    System.out.println("Veuillez entrer tous les champs ");
                }
            }
            
            if(index ==7){ //table infirmier
                f=0;
                table="infirmier";
                String st1 = textes_service.get(1).getText().trim();
                String st2 = textes_service.get(2).getText().trim();
                String st3 = textes_service.get(3).getText().trim();
                
                if(textes_service.get(0).getText().length()!=0){
                    b=Integer.parseInt(textes_service.get(0).getText().trim());
                }
                if(st1.compareTo("")!=0 && st2.compareTo("")!=0 && st3.compareTo("")!=0 && b!=0){
                    req="";
                    res.setLayout(new GridLayout(0,2));
                    res.removeAll();
                    ArrayList<String> liste = new ArrayList<String>();
                    req = "UPDATE FROM `infirmier` SET "+"`nom` = '"+st1+"', `prenom` = '"+st2+"', adresse = '"+st3+"' WHERE `numero` = "+f;
                    try {
                        liste = co.remplirChampsRequete(req);
                        result(liste);
                    } catch (SQLException ex) {
                        System.out.println("Erreur SQL Update");
                        //Logger.getLogger(FenMaj.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                else {
                    System.out.println("Veuillez entrer tous les champs ");
                }
            }
        }
        
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
