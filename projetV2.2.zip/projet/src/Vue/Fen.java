/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vue;

import Modele.Connexion;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.*;


/**
 *
 * @author Merlo
 */
public class Fen extends JFrame implements ActionListener, ItemListener {
    
    private JTabbedPane connRech;
    private JTabbedPane classe;
    
    private Connexion maco;
    private JLabel logECE, passwdECE, logBDD, passwdBDD, nameBDD;
    private JTextField logECEText, logBDDText, nameBDDText;
    private JPasswordField passwdECEText, passwdBDDText;
    private JButton connECE, connBDD, execReq, fenMaj,fenMaj2;
    private java.awt.List listeDeTables, listeDeRequetes;
    private JTextArea fenetreRes;
    
    
    private JPanel pan1,pan2,pan3,pan4,pan5,pan6,pan7,pan8,panA,panB,panA1,panA2,panB1,res;
    private JScrollPane scroll;
	
    
    ArrayList<JTextField> textes_malade = new ArrayList<JTextField>();
    ArrayList<JTextField> textes_service = new ArrayList<JTextField>();
    ArrayList<JTextField> textes_chambre = new ArrayList<JTextField>();
    ArrayList<JTextField> textes_soin = new ArrayList<JTextField>();
    ArrayList<JTextField> textes_employe = new ArrayList<JTextField>();
    ArrayList<JTextField> textes_hospitalisation = new ArrayList<JTextField>();
    ArrayList<JTextField> textes_docteur = new ArrayList<JTextField>();
    ArrayList<JTextField> textes_infirmier = new ArrayList<JTextField>();
    
    public Fen(){
        super("Connexion et recharche dans la BDD");
        this.setLayout(new BorderLayout());
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(800, 800);
        
        // creation des listes pour les tables et les requetes
        listeDeTables = new java.awt.List(10, false);
        listeDeRequetes = new java.awt.List(10, false);
        
        connRech = new JTabbedPane();
        classe =  new JTabbedPane();
        
        this.add(connRech);
       
        
        panA= new JPanel();
        panA1= new JPanel();
        panA2= new JPanel();
        res= new JPanel();
        panB= new JPanel();
        pan1= new JPanel();
        pan2= new JPanel();
        pan3= new JPanel();
        pan4= new JPanel();
        pan5= new JPanel();
        pan6= new JPanel();
        pan7= new JPanel();
        pan8= new JPanel();
        
        
        connRech.add("Connexion", panA);
        connRech.add("Rechercher",panB);
        
        
        panA.setLayout(new BorderLayout());
        panB.setLayout(new BorderLayout());
        
        
       
        panA1.setSize(new Dimension(800, 400));
        panA2.setSize(new Dimension(800, 100));
        //panA3.setSize(new Dimension(800, 100));
        
        
        
       
        classe.add("Malade", pan1);
        classe.add("Service", pan2);
        classe.add("Chambre", pan3);
        classe.add("Soin", pan4);
        classe.add("Employé", pan5);
        classe.add("Hospitalisation", pan6);
        classe.add("Docteur", pan7);
        classe.add("Infirmier", pan8);
        
        panB.add(classe,BorderLayout.NORTH);
        
        logECE= new JLabel("Login ECE",JLabel.CENTER); //creation des textes 
        passwdECE= new JLabel("Password ECE",JLabel.CENTER); 
        logBDD= new JLabel("Login BDD",JLabel.CENTER); 
        passwdBDD= new JLabel("Password BDD",JLabel.CENTER); 
        nameBDD= new JLabel("Nom BDD",JLabel.CENTER); 
        
        connECE = new JButton("Connexion ECE");
        connBDD = new JButton("Connexion BDD");
        execReq= new JButton("Rechercher");
        fenMaj = new JButton("Effectuer une Maj \n(ouvre une autre fenetre)");
        fenMaj2 = new JButton("Effectuer une Maj \n(ouvre une autre fenetre)");
        fenMaj2.setSize(100,20);
        
        logECEText = new JTextField(); //emplacement pour ecrire 
        logBDDText = new JTextField();
        nameBDDText = new JTextField();
        
        passwdECEText = new JPasswordField(8); //emplacement pour ecrire mdp
        passwdBDDText = new JPasswordField(8);
        
        connECE.setPreferredSize(new Dimension(150,30));
        connBDD.setPreferredSize(new Dimension(150,30));
        logECEText.setPreferredSize(new Dimension(100,20));
        logBDDText.setPreferredSize(new Dimension(100,20));
        nameBDDText.setPreferredSize(new Dimension(100,20));
        passwdECEText.setPreferredSize(new Dimension(100,20));
        passwdBDDText.setPreferredSize(new Dimension(100,20));
        
        
        connECE.addActionListener(this);
        connBDD.addActionListener(this);
        execReq.addActionListener(this);
        fenMaj.addActionListener(this);
        fenMaj2.addActionListener(this);
        
        panA1.add(logECE); // ajout des élément au pan 
        panA1.add(logECEText);
        panA1.add(passwdECE);
        panA1.add(passwdECEText);
        panA2.add(logBDD);
        panA2.add(logBDDText);
        panA2.add(passwdBDD);
        panA2.add(passwdBDDText);
        panA2.add(nameBDD);
        panA2.add(nameBDDText);
        panA1.add(connECE);
        panA2.add(connBDD);
        
        panB1 = new JPanel(new GridLayout(1,2));
        
        
        panA.add(panA1,BorderLayout.NORTH);
        panA.add(panA2,BorderLayout.CENTER);
        panA.add(fenMaj2,BorderLayout.SOUTH);
        
        panB1.add(execReq);
        panB1.add(fenMaj);
        panB.add(panB1,BorderLayout.SOUTH);
        
        res.setBackground(Color.WHITE);
        scroll = new JScrollPane(res,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        
        scroll.setLayout(new ScrollPaneLayout());
        scroll.setSize(new Dimension(300, 300));
        panB.add(scroll,BorderLayout.CENTER);
        
       
       
        
        mal();
        serv();
        ch();
        soigne();
        empl();
        hospi();
        doc();
        inf();
        
        this.setVisible(true);
        
    }
    
    public void mal(){
        pan1.setLayout(new GridLayout(3,2));
        JLabel label1 = new JLabel("Numero");
        JLabel label2 = new JLabel("Nom");
        JLabel label3 = new JLabel("Prenom");
	JLabel label4 = new JLabel("Adresse");
	JLabel label5 = new JLabel("Telephone");
        JLabel label6 = new JLabel("Mutuelle");
        
        JTextField text1 = new JTextField();
	JTextField text2 = new JTextField();
	JTextField text3 = new JTextField();
	JTextField text4 = new JTextField();
	JTextField text5 = new JTextField();
        JTextField text6 = new JTextField();
        
        text1.setPreferredSize(new Dimension(100,20));
        text2.setPreferredSize(new Dimension(100,20));
        text3.setPreferredSize(new Dimension(100,20));
        text4.setPreferredSize(new Dimension(100,20));
        text5.setPreferredSize(new Dimension(100,20));
        text6.setPreferredSize(new Dimension(100,20));
        
        JPanel p1 = new JPanel();
	JPanel p2 = new JPanel();
	JPanel p3 = new JPanel();
	JPanel p4 = new JPanel();
	JPanel p5 = new JPanel();
	JPanel p6 = new JPanel();
        
        textes_employe.add(text1);
        textes_employe.add(text2);
        textes_employe.add(text3);
        textes_employe.add(text4);
        textes_employe.add(text5);
        textes_employe.add(text6);
        
        p1.add(label1);
        p1.add(text1);
        p2.add(label2);
        p2.add(text2);
        p3.add(label3);
        p3.add(text3);
        p4.add(label4);
        p4.add(text4);
        p5.add(label5);
        p5.add(text5);
        p6.add(label6);
        p6.add(text6);
      
        
        pan1.add(p1);
        pan1.add(p2);
        pan1.add(p3);
        pan1.add(p4);
        pan1.add(p5);
        pan1.add(p6);
           
    }
    public void serv(){
        pan2.setLayout(new GridLayout(2,4));
        JLabel label1 = new JLabel("Code");
        JLabel label2 = new JLabel("Nom");
        JLabel label3 = new JLabel("Batiment");
	JLabel label4 = new JLabel("Directeur");

        
        JTextField text1 = new JTextField();
	JTextField text2 = new JTextField();
	JTextField text3 = new JTextField();
	JTextField text4 = new JTextField();
	
        text1.setPreferredSize(new Dimension(100,20));
        text2.setPreferredSize(new Dimension(100,20));
        text3.setPreferredSize(new Dimension(100,20));
        text4.setPreferredSize(new Dimension(100,20));
        
        JPanel p1 = new JPanel();
	JPanel p2 = new JPanel();
	JPanel p3 = new JPanel();
	JPanel p4 = new JPanel();
	
        
        textes_service.add(text1);
        textes_service.add(text2);
        textes_service.add(text3);
        textes_service.add(text4);
    
        
        p1.add(label1);
        p1.add(text1);
        p2.add(label2);
        p2.add(text2);
        p3.add(label3);
        p3.add(text3);
        p4.add(label4);
        p4.add(text4);
   
        pan2.add(p1);
        pan2.add(p2);
        pan2.add(p3);
        pan2.add(p4);
   
     } 
    public void ch(){
        pan3.setLayout(new GridLayout(2,4));
        JLabel label1 = new JLabel("Code Service");
        JLabel label2 = new JLabel("Numero chambre");
        JLabel label3 = new JLabel("Surveillant");
	JLabel label4 = new JLabel("Nombre lit");

        
        JTextField text1 = new JTextField();
	JTextField text2 = new JTextField();
	JTextField text3 = new JTextField();
	JTextField text4 = new JTextField();

        text1.setPreferredSize(new Dimension(100,20));
        text2.setPreferredSize(new Dimension(100,20));
        text3.setPreferredSize(new Dimension(100,20));
        text4.setPreferredSize(new Dimension(100,20));
        
        JPanel p1 = new JPanel();
	JPanel p2 = new JPanel();
	JPanel p3 = new JPanel();
	JPanel p4 = new JPanel();

        
        textes_chambre.add(text1);
        textes_chambre.add(text2);
        textes_chambre.add(text3);
        textes_chambre.add(text4);
      
        
        p1.add(label1);
        p1.add(text1);
        p2.add(label2);
        p2.add(text2);
        p3.add(label3);
        p3.add(text3);
        p4.add(label4);
        p4.add(text4);
    
        pan3.add(p1);
        pan3.add(p2);
        pan3.add(p3);
        pan3.add(p4);
   
    } 
    public void soigne(){
        pan4.setLayout(new GridLayout(1,2));
        JLabel label1 = new JLabel("Numero Docteur");
	JLabel label2 = new JLabel("Numero Malade");
        
        JTextField text1 = new JTextField();
	JTextField text2 = new JTextField();
        
        text1.setPreferredSize(new Dimension(100,20));
        text2.setPreferredSize(new Dimension(100,20));
        
        JPanel p1 = new JPanel();
	JPanel p2 = new JPanel();
        
        textes_soin.add(text1);
        textes_soin.add(text2);
        
        p1.add(label1);
        p1.add(text1);
        p2.add(label2);
        p2.add(text2);
        
        pan4.add(p1);
        pan4.add(p2);
    }
    public void empl(){
        pan5.setLayout(new GridLayout(3,4));
        JLabel label1 = new JLabel("Numero");
        JLabel label2 = new JLabel("Nom");
        JLabel label3 = new JLabel("Prenom");
	JLabel label4 = new JLabel("Adresse");
	JLabel label5 = new JLabel("Telephone");
        
        JTextField text1 = new JTextField();
	JTextField text2 = new JTextField();
	JTextField text3 = new JTextField();
	JTextField text4 = new JTextField();
	JTextField text5 = new JTextField();
        
        text1.setPreferredSize(new Dimension(100,20));
        text2.setPreferredSize(new Dimension(100,20));
        text3.setPreferredSize(new Dimension(100,20));
        text4.setPreferredSize(new Dimension(100,20));
        text5.setPreferredSize(new Dimension(100,20));
        
        JPanel p1 = new JPanel();
	JPanel p2 = new JPanel();
	JPanel p3 = new JPanel();
	JPanel p4 = new JPanel();
	JPanel p5 = new JPanel();
	
        
        textes_employe.add(text1);
        textes_employe.add(text2);
        textes_employe.add(text3);
        textes_employe.add(text4);
        textes_employe.add(text5);
        
        p1.add(label1);
        p1.add(text1);
        p2.add(label2);
        p2.add(text2);
        p3.add(label3);
        p3.add(text3);
        p4.add(label4);
        p4.add(text4);
        p5.add(label5);
        p5.add(text5);
      
        
        pan5.add(p1);
        pan5.add(p2);
        pan5.add(p3);
        pan5.add(p4);
        pan5.add(p5);
           
    }
    public void hospi(){
        pan6.setLayout(new GridLayout(2,4));
        JLabel label1 = new JLabel("Numero malade");
        JLabel label2 = new JLabel("Code service");
        JLabel label3 = new JLabel("Numero chambre");
	JLabel label4 = new JLabel("Lit");
	
        
        JTextField text1 = new JTextField();
	JTextField text2 = new JTextField();
	JTextField text3 = new JTextField();
	JTextField text4 = new JTextField();
        
        
        text1.setPreferredSize(new Dimension(100,20));
        text2.setPreferredSize(new Dimension(100,20));
        text3.setPreferredSize(new Dimension(100,20));
        text4.setPreferredSize(new Dimension(100,20));
        
        
        JPanel p1 = new JPanel();
	JPanel p2 = new JPanel();
	JPanel p3 = new JPanel();
	JPanel p4 = new JPanel();
        
        textes_hospitalisation.add(text1);
        textes_hospitalisation.add(text2);
        textes_hospitalisation.add(text3);
        textes_hospitalisation.add(text4);
        
        p1.add(label1);
        p1.add(text1);
        p2.add(label2);
        p2.add(text2);
        p3.add(label3);
        p3.add(text3);
        p4.add(label4);
        p4.add(text4);
        
        pan6.add(p1);
        pan6.add(p2);
        pan6.add(p3);
        pan6.add(p4);
    } 
    public void doc(){
        pan7.setLayout(new GridLayout(1,2));
        JLabel label1 = new JLabel("Numero ");
	JLabel label2 = new JLabel("Specialité");
        
        JTextField text1 = new JTextField();
	JTextField text2 = new JTextField();
        
        text1.setPreferredSize(new Dimension(100,20));
        text2.setPreferredSize(new Dimension(100,20));
        
        JPanel p1 = new JPanel();
	JPanel p2 = new JPanel();
        
        textes_docteur.add(text1);
        textes_docteur.add(text2);
        
        p1.add(label1);
        p1.add(text1);
        p2.add(label2);
        p2.add(text2);
        
        pan7.add(p1);
        pan7.add(p2);
    }
    public void inf(){
        pan8.setLayout(new GridLayout(3,4));
        JLabel label1 = new JLabel("Numero");
        JLabel label2 = new JLabel("Nom");
        JLabel label3 = new JLabel("Prenom");
	JLabel label4 = new JLabel("Adresse");
        
        JTextField text1 = new JTextField();
	JTextField text2 = new JTextField();
	JTextField text3 = new JTextField();
	JTextField text4 = new JTextField();
        
        text1.setPreferredSize(new Dimension(100,20));
        text2.setPreferredSize(new Dimension(100,20));
        text3.setPreferredSize(new Dimension(100,20));
        text4.setPreferredSize(new Dimension(100,20));
        
        JPanel p1 = new JPanel();
	JPanel p2 = new JPanel();
	JPanel p3 = new JPanel();
	JPanel p4 = new JPanel();
	
        
        textes_infirmier.add(text1);
        textes_infirmier.add(text2);
        textes_infirmier.add(text3);
        textes_infirmier.add(text4);
        
        p1.add(label1);
        p1.add(text1);
        p2.add(label2);
        p2.add(text2);
        p3.add(label3);
        p3.add(text3);
        p4.add(label4);
        p4.add(text4);
      
        
        pan8.add(p1);
        pan8.add(p2); 
        pan8.add(p3);
        pan8.add(p4);
    }
    
    
    /**
     * Méthode privée qui initialise la liste des tables
     */
    private void remplirTables() {
        maco.ajouterTable("chambre");
        maco.ajouterTable("docteur");
        maco.ajouterTable("employe");
        maco.ajouterTable("hospitalisation");
        maco.ajouterTable("infirmier");
        maco.ajouterTable("malade");
        maco.ajouterTable("service");
        maco.ajouterTable("soigne");
    }

    /**
     * Méthode privée qui initialise la liste des requetes de selection
     */
    private void remplirRequetes() {
        maco.ajouterRequete("SELECT * FROM docteur;");
        }

    /**
     * Méthode privée qui initialise la liste des requetes de MAJ
     */
    private void remplirRequetesMaj() {
        // Requêtes d'insertion
        maco.ajouterRequeteMaj("INSERT INTO malade (numero, nom, prenom, adresse,tel, mutuelle) VALUES (77,'Henri', 'Dupont,'',Paris');");

        // Requêtes de modification
        maco.ajouterRequeteMaj("UPDATE malade SET loc='Eiffel' WHERE loc='Paris';");

        // Requêtes de suppression
        maco.ajouterRequeteMaj("DELETE FROM malade WHERE ='Eiffel';");

    }

    
    @Override
    public void actionPerformed(ActionEvent e) {
        Object s = e.getSource();
        if(s==fenMaj){
            FenMaj Fmaj = new FenMaj(maco);
        }
        if(s==fenMaj2){
            FenMaj Fmaj = new FenMaj(maco);
        }
        if(s==connECE){
            ArrayList<String> liste;
            String passwdECEString = new String(passwdECEText.getPassword());
            String passwdBDDString = new String(passwdBDDText.getPassword());
    
        try {
                try {
                    // tentative de connexion si les 4 attributs sont remplis
                    maco = new Connexion(logECEText.getText(), passwdECEString,logBDDText.getText(), passwdBDDString);

                    // effacer les listes de tables et de requêtes
                    listeDeTables.removeAll();
                    listeDeRequetes.removeAll();

                    // initialisation de la liste des requetes de selection et de MAJ
                    remplirTables();
                    remplirRequetes();
                    remplirRequetesMaj();


                    // se positionner sur la première table et requête de selection
                    listeDeTables.select(0);
                    listeDeRequetes.select(0);

                    // recuperer la liste des lignes de la requete selectionnee
                    String requeteSelectionnee = listeDeRequetes.getSelectedItem();

                    // afficher les résultats de la requete selectionnee
                    //afficherRes(requeteSelectionnee);
                } catch (ClassNotFoundException cnfe) {
                    System.out.println("Connexion echouee : probleme de classe");
                    cnfe.printStackTrace();
                }
            }catch (SQLException ex) {
                System.out.println("Connexion echouee : probleme SQL");
                ex.printStackTrace();
            }
        }else if (s == connBDD) {
            ArrayList<String> liste;
            try {
                try {
                    // tentative de connexion si les 4 attributs sont remplis
                    maco = new Connexion(nameBDDText.getText(), "root", "root");

                    // effacer les listes de tables et de requêtes
                    listeDeTables.removeAll();
                    listeDeRequetes.removeAll();

                    // initialisation de la liste des requetes de selection et de MAJ
                    remplirTables();
                    remplirRequetes();
                    remplirRequetesMaj();

                   

                    // se positionner sur la première table et requête de selection
                    listeDeTables.select(0);
                    listeDeRequetes.select(0);

                    // afficher les champs de la table sélectionnée
                    String nomTable = listeDeTables.getSelectedItem();

                  
                    // recuperer la liste des lignes de la requete selectionnee
                    String requeteSelectionnee = listeDeRequetes.getSelectedItem();

                    // afficher les résultats de la requete selectionnee
                    //afficherRes(requeteSelectionnee);
                } catch (ClassNotFoundException cnfe) {
                    System.out.println("Connexion echouee : probleme de classe");
                    cnfe.printStackTrace();
                }
            } catch (SQLException ex) {
                System.out.println("Connexion echouee : probleme SQL");
                ex.printStackTrace();
            }
            
        }
        else if(s== execReq){
            
        }
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates. 
    }

    @Override
    public void itemStateChanged(ItemEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
